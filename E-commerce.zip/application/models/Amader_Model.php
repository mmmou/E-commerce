<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Amader_Model extends CI_Model {

   public $Id;

   public function save_data($table, $data) {
      if ($this->db->insert($table, $data)) {
         $this->Id = $this->db->insert_id();
         return TRUE;
      } else {
         return FALSE;
      }
   }

   public function update_data($table, $data, $where) {
      $this->db->where($where);
      if ($this->db->update($table, $data)) {
         return TRUE;
      } else {
         return FALSE;
      }
   }

   public function view_data($table, $where) {
      if ($where) {
         $this->db->where($where);
      }
      $this->db->select("*");
      $this->db->from("$table");
      $this->db->order_by("id", "asc");
      return $this->db->get()->result();
   }
   
   public function sidebar($where){
      if ($where) {
         $this->db->where($where);
      }
      $this->db->select("category.*");
      $this->db->from("product");
      $this->db->join("subcategory", "subcategory.id=product.subcategoryid");
      $this->db->join("category", "category.id=subcategory.categoryid");
      $this->db->order_by("category.name", "asc");
      $this->db->group_by("category.id");
      return $this->db->get()->result();      
   }
   
   public function topSell() {
      $this->db->select("(select sum(saledetails.qty) from saledetails where saledetails.productid = product.id) tSell");
      $this->db->from("product");
      $this->db->join("addproduct", "addproduct.productid = product.id", "left");
      $this->db->join("saledetails", "saledetails.productid = product.id", "left");
      $this->db->order_by("tSell", "desc");
      $this->db->group_by("product.id");
      $this->db->limit(5);
      return $this->db->get()->result();
   }

   public function productStock($id) {
      $this->db->where(array("product.id" => $id));
      $this->db->select("product.stock, (select sum(addproduct.stock) from addproduct where addproduct.productid = product.id) apStock, (select sum(saledetails.qty) from saledetails where saledetails.productid = product.id) tSell, product.price, product.discount, product.vat");
      $this->db->from("product");
      $this->db->join("addproduct", "addproduct.productid = product.id", "left");
      $this->db->join("saledetails", "saledetails.productid = product.id", "left");
      $this->db->group_by("product.id");
      return $this->db->get()->result();
   }

   public function product_details($where) {
      $this->db->where(array("product.id" => $where));
      $this->db->select("product.id, product.title, product.picture, product.vat, product.discount, product.price, unit.name unitname, color.id colorid, color.name colorname, subcategory.name sname, category.name cname, size.name sizename, tags.name tagsname");
      $this->db->from("product");
      $this->db->join("unit", "unit.id=product.unitid");
      $this->db->join("subcategory", "subcategory.id=product.subcategoryid");
      $this->db->join("category", "category.id=subcategory.categoryid");
      $this->db->join("productcolor", "productcolor.productid=product.id", "left");
      $this->db->join("color", "productcolor.colorid=color.id", "left");
      $this->db->join("productsize", "productsize.productid=product.id", "left");
      $this->db->join("size", "productsize.sizeid=size.id", "left");
      $this->db->join("producttags", "producttags.tagsid=product.id", "left");
      $this->db->join("tags", "producttags.tagsid=tags.id", "left");
      return $this->db->get()->result();
   }

   public function view_subcategory() {
      $this->db->select("subcategory.*, (select count(product.id) from product where subcategory.id = product.subcategoryid) tProduct");
      $this->db->from("subcategory");
      $this->db->join("product", "subcategory.id = product.subcategoryid", "left");
      $this->db->order_by("subcategory.name", "asc");
      $this->db->group_by("subcategory.id");
      return $this->db->get()->result();
   }

   public function view_product($table, $where) {
      if ($where) {
         $this->db->where($where);
      }
      $this->db->select("*");
      $this->db->from("$table");
      $this->db->order_by("id", "asc");
      return $this->db->get()->result();
   }
   
   public function view_product_page($limit, $start) {
      $this->db->select("product.*, subcategory.name scname, category.name cname");
      $this->db->from("product");
      $this->db->join("subcategory", "product.subcategoryid = subcategory.id");
      $this->db->join("category", "subcategory.categoryid = category.id");
      $this->db->order_by("product.id", "desc");
      $this->db->limit($start, $limit);
      return $this->db->get()->result();
   }
   public function totalPdt(){
      $this->db->select("count(id) total");
      $this->db->from("product");
      return $this->db->get()->result();
   }

   public function delete_data($table, $where = array()) {
      $this->db->where($where);
      $res = $this->db->delete($table);
      if ($res) {
         return TRUE;
      } else {
         return FALSE;
      }
   }

   public function checkoutpdt($where) {
      if ($where) {
         $this->db->where_in("id", $where);
      }
      $this->db->select("*");
      $this->db->from("product");
      return $this->db->get()->result();
   }

   public function Search($title, $sdate, $edate, $catid, $scatid, $uid, $utype) {
      if($title != ""){
         $this->db->like('product.title', $title);
      }
      if (trim($sdate) != "" && $edate != "") {
         $this->db->where("sale.date >=", $sdate . " 00:00:00");
         $this->db->where("sale.date <=", $edate . " 23:59:59");
      }
      else if ($sdate != "") {
         $this->db->where("sale.date >=", $sdate . " 00:00:00");
         $this->db->where("sale.date <=", $sdate . " 23:59:59");
      }
      else if ($edate != "") {
         $this->db->where("sale.date >=", $edate . " 00:00:00");
         $this->db->where("sale.date <=", $edate . " 23:59:59");
      }
      
      if($scatid > 0){
         $this->db->where("subcategory.id", $scatid);
      }
      else if($catid > 0){
         $this->db->where("category.id", $catid);
      }
      
      if($utype != "a"){
         $this->db->where("customer.id", $uid);
      }
      
      
      $this->db->select("product.id, product.title, saledetails.qty, saledetails.vat, saledetails.discount, sale.date, customer.name");
      $this->db->from("product");
      $this->db->join("saledetails", "saledetails.productid = product.id");
      $this->db->join("sale", "sale.id = saledetails.saleid");
      $this->db->join("subcategory", "subcategory.id = product.subcategoryid");
      $this->db->join("category", "category.id = subcategory.categoryid");
      $this->db->join("customer", "customer.id = sale.customerid");
      return $this->db->get()->result();
   }

   public function Comment($id){
      $this->db->select("customer.name, comment.rating, comment.date");
      $this->db->from("product");
      $this->db->join("comment", "comment.productid = product.id");
      $this->db->join("customer", "customer.id = comment.customerid");
      return $this->db->get()->result();
   }
   
   public function MyCaptche() {
        $this->load->helper('captcha');
        $word = RandString(6);
        $captcha = array(
            'word' => $word,
            'img_path' => './captcha/',
            'img_url' => base_url() . 'captcha/',
            'font_path' => './fonts/DJB Speak the Truth Boldly.ttf',
            'img_width' => '150',
            'img_height' => '34',
            'expiration' => '600',
            'time' => time()
        );

        $expire = $captcha['time'] - $captcha['expiration'];
        $this->db->where('time < ', $expire);
        $this->db->select("img_name");
        $r = $this->db->get("captcha")->result();
        foreach ($r as $v) {
            unlink("captcha/" . $v->img_name);
        }

        $this->db->where('time < ', $expire);
        $this->db->delete('captcha');

        $img = create_captcha($captcha);

        $value = array(
            'time' => $captcha['time'],
            'word' => $captcha['word'],
            'img_name' => $img['time'] . ".jpg"
        );

        $this->db->insert('captcha', $value);
        $data['id'] = $this->db->insert_id();
        $data['cap_name'] = $img['time'] . ".jpg";

        return $data;
    }
    
    public function View_Data_for_captcha($table, $sel, $rel) {
      if ($rel) {
         $this->db->where($rel);
      }
      $this->db->select($sel);
      return $this->db->get($table)->result();
   }
}
