<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Subcategory_Management extends CI_Controller {

    public function index() {
        $data = array();
        $this->load->helper('form');
        $data['allCat'] = $this->am->view_data("category", "");
        $data['title'] = "Subcategory Management";
        $data['content'] = $this->load->view("backend/subcategory-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('scat', 'Subcategory', 'required|trim');

        $this->form_validation->set_rules('catid', 'Category', 'required|trim');


        if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper('form');
            $data['allCat'] = $this->am->view_data("category", "");
            $data['title'] = "Subcategory Management";
            $data['content'] = $this->load->view("backend/subcategory-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("scat"),
                "categoryid" => $this->input->post("catid")
            );
            if ($this->am->save_data("subcategory", $data)) {
                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "subcategory_management", "refresh");
        }
    }

    public function view() {
        $data = array();

        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allCat'] = $this->am->view_data("category", "");
        $data['title'] = "Subcategory View";
        $data['content'] = $this->load->view("backend/subcategory-view", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function edit() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");

        $data['selSCat'] = $this->am->view_data("subcategory", array("id" => $id));
        $data['allCat'] = $this->am->view_data("category", "");

        //print_r($data['selColor']);
        $data['title'] = "Subcategory Management";
        $data['content'] = $this->load->view("backend/subcategory-edit", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function update() {
        $this->load->helper("form");
        $this->load->library('form_validation');


        $this->form_validation->set_rules('scat', 'Subcategory', 'required|trim');

        $this->form_validation->set_rules('categoryid', 'Category', 'required|trim');


        if ($this->form_validation->run() == FALSE) {
            $data = array();
            $this->load->helper('form');
            $data['allCat'] = $this->am->view_data("category", "");
            $data['title'] = "Subcategory Management";
            $data['content'] = $this->load->view("backend/subcategory-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("scat"),
                "categoryid" => $this->input->post("categoryid")
            );
            $id = $this->input->post("id");

            if ($this->am->update_data("subcategory", $data, array("id" => $id))) {

                $sdata['msg'] = "Update Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "subcategory_management/view", "refresh");
        }
    }

    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();

        $selScat = $this->am->view_data("subcategory", array("id" => $id));
        $selPdt = $this->am->view_data("product", "");
        foreach ($selScat as $scat) {
            foreach ($selPdt as $spdt) {
                if (($scat->id) == ($spdt->subcategoryid)) {

                    $data['selPdt'] = $this->am->view_product("product", array("id" => $id));
                    $selPdt = $this->am->view_product("product", array("id" => $id));
                    foreach ($selPdt as $pdt) {
                        $ext = $pdt->picture;
                    }
                    unlink("product/final/product_{$id}.{$spdt->$ext}");
                    unlink("files/product_{$id}.txt");

                    $this->am->delete_data("addproduct", array("productid" => $id));
                    $this->am->delete_data("comment", array("productid" => $id));
                    $this->am->delete_data("productcolor", array("productid" => $id));
                    $this->am->delete_data("producttags", array("productid" => $id));
                    $this->am->delete_data("productunit", array("productid" => $id));
                    $this->am->delete_data("productsize", array("productid" => $id));
                    $this->am->delete_data("product", array("id" => $id));

                    $this->am->delete_data("subcategory", array("id" => $id));
                    if ($this->am->delete_data("subcategory", array("id" => $id))) {
                        echo "Delete Successful";
                    } else {
                        echo "Some error occurs";
                    }
                } 
            }
        }
        
        $this->am->delete_data("subcategory", array("id" => $id));
        if ($this->am->delete_data("subcategory", array("id" => $id))) {
            echo "Delete Successful";
        } else {
            echo "Some error occurs";
        }
        //$this->session->set_userdata($sdata);
        //redirect(base_url() . "subcategory_management/view", "refresh");
    }

}

/*
 $this->am->delete_data("subcategory", array("id" => $id));
        if ($this->am->delete_data("subcategory", array("id" => $id))) {
            echo "Delete Successful";
        } else {
            echo "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        //redirect(base_url() . "subcategory_management/view", "refresh");
 */