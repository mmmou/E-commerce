<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Tags_Management extends CI_Controller {

    public function index() {
        $data = array();
        $this->load->helper('form');
        $data['title'] = "Tags Management";
        $data['content'] = $this->load->view("backend/tags-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('tag', 'Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper("form");
            //print_r($data['allUnit']);
            $data['title'] = "Tags Management";
            $data['content'] = $this->load->view("backend/tags-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("tag")
            );
            if ($this->am->save_data("Tags", $data)) {
                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "tags_management", "refresh");
        }
    }

    public function view() {
        $data = array();
        $data['alltags'] = $this->am->view_data("tags", "");
        $data['title'] = "Tags View";
        $data['content'] = $this->load->view("backend/tags-view", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function edit() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");

        $data['selTags'] = $this->am->view_data("tags", array("id" => $id));



        //print_r($data['selTags']);
        $data['title'] = "Tags Management";
        $data['content'] = $this->load->view("backend/tags-edit", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function update() {

        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('tag', 'Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper('form');
            $data['title'] = "Tags Management";
            $data['content'] = $this->load->view("backend/tags-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("tag")
            );
            $id = $this->input->post("id");

            if ($this->am->update_data("tags", $data, array("id" => $id))) {

                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "tags_management/view", "refresh");
        }
    }

    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->am->delete_data("producttags", array("productid" => $id));
        $this->am->delete_data("tags", array("id" => $id));
        if ($this->am->delete_data("tags", array("id" => $id))) {
            $sdata['msg'] = "Delete Successful";
        } else {
            $sdata['msg'] = "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        redirect(base_url() . "tags_management/view", "refresh");
    }

}
