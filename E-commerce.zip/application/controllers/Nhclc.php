<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Nhclc extends CI_Controller {

   public function index() {
      $data = array();
      $data['title'] = "Home";
      $data['per_page'] = 3;
      $totalPdt= $this->am->totalPdt();
      foreach ($totalPdt as $t){
         $data['totalPdt'] = $t->total;
      }
      
      if(isset($_GET['page'])){
         $start = ($_GET['page']-1) * $data['per_page'];
         $data['cpage'] = $_GET['page'];
      }
      else{
         $start = 0;
         $data['cpage'] = 1;
      }
      
      $dddd = $this->am->topSell();
      //print_r($dddd);
      
      $data['allPdt'] = $this->am->view_product_page($start, 6);
      $data['allCat'] = $this->am->sidebar("");
      $data['allSCat'] = $this->am->view_subcategory();     
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/home", $data, true);
      $this->load->view("master", $data);
   }

   public function tac() {
      $data = array();
      $data['title'] = "Terms and Conditions";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/tac", $data, true);
      $this->load->view("master", $data);
   }

   public function legal_notice() {
      $data = array();
      $data['title'] = "Legal Notice";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/legal_notice", $data, true);
      $this->load->view("master", $data);
   }

   public function register() {
      $data = array();
      $data['title'] = "Register";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/register", $data, true);
      $this->load->view("master", $data);
   }

   public function login() {
      $data = array();
      $data['title'] = "Login";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/login", $data, true);
      $this->load->view("master", $data);
   }

   public function forgetpass() {
      $data = array();
      $data['title'] = "Forget Password";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/forgetpass", $data, true);
      $this->load->view("master", $data);
   }

   public function faq() {
      $data = array();
      $data['title'] = "FAQ";
      $data['content'] = $this->load->view("frontend/faq", "", true);
      $this->load->view("master", $data);
   }

   public function special_offer() {
      $data = array();
      $data['title'] = "Special Offer";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/special_offer", $data, true);
      $this->load->view("master", $data);
   }

   public function delivery() {
      $data = array();
      $data['title'] = "Delivery";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/delivery", $data, true);
      $this->load->view("master", $data);
   }

   public function contact() {
      $data = array();
      $data['title'] = "Contact";
      $data['content'] = $this->load->view("frontend/contact", "", true);
      $this->load->view("master", $data);
   }

   public function products() {
      $data = array();
      $data['title'] = "Products";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/products", $data, true);
      $this->load->view("master", $data);
   }

   public function product_details() {
      $data = array();
      $data['title'] = "Product Details";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/product_details", $data, true);
      $this->load->view("master", $data);
   }

   public function product_summary() {
      $data = array();
      $data['title'] = "Product Summary";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/product_summary", $data, true);
      $this->load->view("master", $data);
   }

   public function compair() {
      $data = array();
      $data['title'] = "Compair";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/compair", $data, true);
      $this->load->view("master", $data);
   }

   public function components() {
      $data = array();
      $data['title'] = "Components";
      $data['content'] = $this->load->view("frontend/components", "", true);
      $this->load->view("master", $data);
   }

}

?>