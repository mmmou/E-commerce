<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase extends CI_Controller {

   public function __construct() {
      parent::__construct();
      $type = $this->session->userdata("type");
      if ($type == NULL) {
         redirect(base_url(), "refresh");
      }
      date_default_timezone_set("Asia/Dhaka");
   }

   public function index() {
      $pdtid = $this->session->userdata("pdtid");
      $qtyid = $this->session->userdata("qtyid");

      if ($pdtid) {
         $data = array(
             "customerid" => $this->session->userdata("id"),
             "date" => date("Y-m-d H:i:s"),
             "shipping" => $this->input->post("shipping")
         );
         if ($this->am->save_data("sale", $data)) {
            $id = $this->am->Id;

            for ($i = 0; $i < count($pdtid); $i++) {
               $sdata = $this->am->view_data("product", array("id" => $pdtid[$i]));
               foreach ($sdata as $dt) {
                  $dd = array(
                      "productid" => $pdtid[$i],
                      "vat" => $dt->vat,
                      "discount" => $dt->discount,
                      "qty" => $qtyid[$i],
                      "saleid" => $id
                  );
                  $this->am->save_data("saledetails", $dd);
               }
            }
            $this->session->unset_userdata("pdtid");
            $this->session->unset_userdata("qtyid");
            $this->session->unset_userdata("pdtPrice");
            
            echo "Purchase Successful";
         }
      } else {
         redirect(base_url(), "refresh");
      }
   }

}

?>
