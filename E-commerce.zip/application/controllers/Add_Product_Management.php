<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Add_Product_Management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        date_default_timezone_set("Asia/Dhaka");
    }

    public function index() {
        $data = array();
        $this->load->helper("form");
       
        $data['allCat'] = $this->am->view_data("category", "");
        
        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allPdt'] = $this->am->view_data("product", "");
       
        //print_r($data['allSCat']);
        $data['title'] = "Add Product Management";
        $data['content'] = $this->load->view("backend/add-product-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');


        $this->form_validation->set_rules('pdtid', 'Product', "required|trim");
        $this->form_validation->set_rules('astock', 'Stock', 'required|trim');

        if ($this->form_validation->run() == FALSE) {
            $data = array();
        $this->load->helper("form");
       
        $data['allCat'] = $this->am->view_data("category", "");
        
        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allPdt'] = $this->am->view_data("product", "");
       
        //print_r($data['allSCat']);
        $data['title'] = "Add Product Management";
        $data['content'] = $this->load->view("backend/add-product-new", $data, TRUE);
        $this->load->view("master", $data);
        } else {
           


            $data = array(
                "productid" => $this->input->post("pdtid"),
                "stock" => $this->input->post("astock"),    
                "date" => date("Y-m-d")
               
            );

            if ($this->am->save_data("addproduct", $data)) {
                $id = $this->am->Id;
                

               

               


                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "add_product_management", "refresh");
        }
    }

}

