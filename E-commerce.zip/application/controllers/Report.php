<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

   public function __construct() {
      parent::__construct();
      $type = $this->session->userdata("type");
      if ($type == NULL) {
         redirect(base_url(), "refresh");
      }
   }

   public function index() {
      $data = array();
      $this->load->helper('form');
      $data['title'] = "Report";
      $sub = $this->input->post("sub");
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_data("subcategory", "");
      if ($sub != NULL) {
         $result = $this->am->Search(
                 $this->input->post("title"), 
                 $this->input->post("sdate"), 
                 $this->input->post("edate"),
                 $this->input->post("catid"),
                 $this->input->post("scatid"),
                 $this->session->userdata("id"),
                 $this->session->userdata("type")
         );
         echo "<pre>";
         print_r($result);
         echo "</pre>";
      }
      $data['content'] = $this->load->view("frontend/report", $data, TRUE);
      $this->load->view("master", $data);
   }

}

?>
