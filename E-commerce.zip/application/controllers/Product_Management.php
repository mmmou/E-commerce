<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product_Management extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $type = $this->session->userdata("type");
        if($type != 'a' && $type != 'e'){
           redirect(base_url() , "refresh");
        }
        date_default_timezone_set("Asia/Dhaka");
    }

    public function index() {
        $data = array();
        $this->load->helper("form");
        $data['allUnit'] = $this->am->view_data("unit", "");
        $data['allCat'] = $this->am->view_data("category", "");
        $data['allSize'] = $this->am->view_data("size", "");
        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allTags'] = $this->am->view_data("tags", "");
        $data['allColors'] = $this->am->view_data("color", "");
        //print_r($data['allSCat']);
        $data['title'] = "Product Management";
        $data['content'] = $this->load->view("backend/product-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');


        $this->form_validation->set_rules('title', 'Title', "required|trim");
        $this->form_validation->set_rules('descr', 'Description', 'required|trim');
        $this->form_validation->set_rules('price', 'Price', 'required|trim');
        $this->form_validation->set_rules('stock', 'Stock', 'required|trim');
        $this->form_validation->set_rules('vat', 'Vat', 'required|trim');
        $this->form_validation->set_rules('discount', 'Discount', 'required|trim');

        if ($this->form_validation->run() == FALSE) {
            $data = array();
            $this->load->helper("form");
            $data['allUnit'] = $this->am->view_data("unit", "");
            $data['allCat'] = $this->am->view_data("category", "");
            $data['allSCat'] = $this->am->view_data("subcategory", "");
            $data['allTags'] = $this->am->view_data("tags", "");
            $data['allColors'] = $this->am->view_data("color", "");
            $data['allSize'] = $this->am->view_data("size", "");
            //print_r($data['allSCat']);
            $data['title'] = "Product Management";
            $data['content'] = $this->load->view("backend/product-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $ext = "";
            if ($_FILES['pic']['name'] != "") {
                $ext = pathinfo($_FILES['pic']['name']);
                $ext = strtolower($ext['extension']);
            }


            $data = array(
                "title" => $this->input->post("title"),
                "price" => $this->input->post("price"),
                "subcategoryid" => $this->input->post("scatid"),
                "stock" => $this->input->post("stock"),
                "unitid" => $this->input->post("unitid"),
                "discount" => $this->input->post("discount"),
                "vat" => $this->input->post("vat"),
                "date" => date("Y-m-d"),
                "picture" => $ext
            );

            if ($this->am->save_data("product", $data)) {
                $id = $this->am->Id;
                write_file("./files/product_{$id}.txt", $this->input->post("descr"));

                if ($ext != "") {
                    $this->load->library('upload');
                    $config['upload_path'] = './product/';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = '10000';
                    $config['max_width'] = '22222';
                    $config['max_height'] = '1500';
                    $config['file_name'] = "product_{$id}.{$ext}";
                    $this->upload->initialize($config); //upload image data
                    $this->upload->do_upload('pic');

                    $data = getimagesize("product/product_{$id}.{$ext}");
                    $width = $data[0];
                    $height = $data[1];
                    if ($width / $height > 1.25) {
                        $tw = floor($height * 1.25);
                        $th = $height;
                        $x_axis = floor(($width - $tw) / 2);
                        $y_axis = 0;
                    } else {
                        $tw = $width;
                        $th = floor($width * .8);
                        $x_axis = 0;
                        $y_axis = floor(($height - $th) / 2);
                    }

                    $this->load->library('image_lib');
                    $config['image_library'] = 'gd2';
                    $config['source_image'] = "product/product_{$id}.{$ext}";
                    $config['new_image'] = "product/final/product_{$id}.{$ext}";
                    $conf['create_thumb'] = TRUE;
                    $conf['thumb_marker'] = "";
                    $config['x_axis'] = $x_axis;
                    $config['y_axis'] = $y_axis;
                    $config['maintain_ratio'] = FALSE;
                    $config['width'] = $tw;
                    $config['height'] = $th;
                    //print_r($config);
                    $this->image_lib->initialize($config);
                    $this->image_lib->crop();
                    $this->image_lib->clear();

                    unlink("product/product_{$id}.{$ext}");
                }

                //Color Section Start
                $colorid = $this->input->post("colorid");
                if ($colorid) {
                    foreach ($colorid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "colorid" => $dt
                        );
                        $this->am->save_data("productcolor", $data);
                    }
                }
                //Color Section End
                //Tags Section Start
                $tagsid = $this->input->post("tagsid");
                if ($tagsid) {
                    foreach ($tagsid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "tagsid" => $dt
                        );
                        $this->am->save_data("producttags", $data);
                    }
                }
                //Tags Section End
                //Size Section Start
                $sizeid = $this->input->post("sizeid");
                if ($sizeid) {
                    foreach ($sizeid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "sizeid" => $dt
                        );
                        $this->am->save_data("productsize", $data);
                    }
                }
                //Size Section End


                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "product_management/view", "refresh");
        }
    }

    public function view() {
        $data = array();
        $data['allPdt'] = $this->am->view_product("product", "");

        $data['allsColor'] = $this->am->view_data("color", "");
        $data['allspdColor'] = $this->am->view_product("productcolor", "");

        $data['allsSize'] = $this->am->view_data("size", "");
        $data['allpdSize'] = $this->am->view_product("productsize", "");

        $data['allsTags'] = $this->am->view_data("tags", "");
        $data['allspdTags'] = $this->am->view_product("producttags", "");


        $data['allUnit'] = $this->am->view_data("unit", "");
        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allCat'] = $this->am->view_data("category", "");
        $data['title'] = "Product View";
        $data['content'] = $this->load->view("backend/product-view", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function edit() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");
        $data['allUnit'] = $this->am->view_data("unit", "");
        $data['allCat'] = $this->am->view_data("category", "");
        $data['allSCat'] = $this->am->view_data("subcategory", "");
        $data['allTags'] = $this->am->view_data("tags", "");
        $data['allColors'] = $this->am->view_data("color", "");
        $data['allSize'] = $this->am->view_data("size", "");

        $data['selPdt'] = $this->am->view_data("product", array("id" => $id));
        $data['selColor'] = $this->am->view_product("productcolor", array("productid" => $id));
        $data['selTags'] = $this->am->view_product("producttags", array("productid" => $id));
        $data['selSize'] = $this->am->view_product("productsize", array("productid" => $id));


        //print_r($data['selColor']);
        $data['title'] = "Product Management";
        $data['content'] = $this->load->view("backend/product-edit", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function update() {
        $this->load->helper("form");
        $this->load->library('form_validation');


        $this->form_validation->set_rules('title', 'Title', "required|trim");
        $this->form_validation->set_rules('descr', 'Description', 'required|trim');
        $this->form_validation->set_rules('price', 'Price', 'required|trim');
        $this->form_validation->set_rules('stock', 'Stock', 'required|trim');
        $this->form_validation->set_rules('vat', 'Vat', 'required|trim');
        $this->form_validation->set_rules('discount', 'Discount', 'required|trim');

        if ($this->form_validation->run() == FALSE) {
            $data = array();
            $this->load->helper("form");
            $data['allUnit'] = $this->am->view_data("unit", "");
            $data['allCat'] = $this->am->view_data("category", "");
            $data['allSCat'] = $this->am->view_data("subcategory", "");
            $data['allTags'] = $this->am->view_data("tags", "");
            $data['allColors'] = $this->am->view_data("color", "");
            $data['allSize'] = $this->am->view_data("size", "");
            //print_r($data['allSCat']);
            $data['title'] = "Product Management";
            $data['content'] = $this->load->view("backend/product-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $id = $this->input->post("id");

            //################### Picture Update Start #########
            $selPdt = $this->am->view_data("product", array("id" => $id));
            foreach ($selPdt as $pdt) {
                $old_ext = $pdt->picture;
            }

            $ext = "";
            if ($_FILES['pic']['name'] != "") {
                $ext = pathinfo($_FILES['pic']['name']);
                $ext = strtolower($ext['extension']);
            }
            if ($ext == "") {
                $ext = $old_ext;
            } else {
                if (file_exists("product/final/product_{$id}.{$old_ext}")) {
                    unlink("product/final/product_{$id}.{$old_ext}");
                }
                $this->load->library('upload');
                $config['upload_path'] = './product/';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = '10000';
                $config['max_width'] = '22222';
                $config['max_height'] = '1500';
                $config['file_name'] = "product_{$id}.{$ext}";
                $this->upload->initialize($config); //upload image data
                $this->upload->do_upload('pic');

                $data = getimagesize("product/product_{$id}.{$ext}");
                $width = $data[0];
                $height = $data[1];
                if ($width / $height > 1.25) {
                    $tw = floor($height * 1.25);
                    $th = $height;
                    $x_axis = floor(($width - $tw) / 2);
                    $y_axis = 0;
                } else {
                    $tw = $width;
                    $th = floor($width * .8);
                    $x_axis = 0;
                    $y_axis = floor(($height - $th) / 2);
                }

                $this->load->library('image_lib');
                $config['image_library'] = 'gd2';
                $config['source_image'] = "product/product_{$id}.{$ext}";
                $config['new_image'] = "product/final/product_{$id}.{$ext}";
                $conf['create_thumb'] = TRUE;
                $conf['thumb_marker'] = "";
                $config['x_axis'] = $x_axis;
                $config['y_axis'] = $y_axis;
                $config['maintain_ratio'] = FALSE;
                $config['width'] = $tw;
                $config['height'] = $th;
                //print_r($config);
                $this->image_lib->initialize($config);
                $this->image_lib->crop();
                $this->image_lib->clear();

                unlink("product/product_{$id}.{$ext}");
            }
            //################### Picture Update End ######

            $data = array(
                "title" => $this->input->post("title"),
                "price" => $this->input->post("price"),
                "subcategoryid" => $this->input->post("scatid"),
                "stock" => $this->input->post("stock"),
                "unitid" => $this->input->post("unitid"),
                "discount" => $this->input->post("discount"),
                "vat" => $this->input->post("vat"),
                "picture" => $ext
            );

            if ($this->am->update_data("product", $data, array("id" => $id))) {
                unlink("files/product_{$id}.txt");
                write_file("./files/product_{$id}.txt", $this->input->post("descr"));

                //Color Section Start
                $this->am->delete_data("productcolor", array("productid"=>$id));
                $colorid = $this->input->post("colorid");
                if ($colorid) {
                    foreach ($colorid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "colorid" => $dt
                        );
                        $this->am->save_data("productcolor", $data);
                    }
                }
                //Color Section End
                //Tags Section Start
                 $this->am->delete_data("producttags", array("productid"=>$id));
                $tagsid = $this->input->post("tagsid");
                if ($tagsid) {
                    foreach ($tagsid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "tagsid" => $dt
                        );
                        $this->am->save_data("producttags", $data);
                    }
                }
                //Tags Section End
                //Size Section Start
                 $this->am->delete_data("productsize", array("productid"=>$id));
                $sizeid = $this->input->post("sizeid");
                if ($sizeid) {
                    foreach ($sizeid as $dt) {
                        $data = array(
                            "productid" => $id,
                            "sizeid" => $dt
                        );
                        $this->am->save_data("productsize", $data);
                    }
                }
                //Size Section End

                $sdata['msg'] = "Update Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "product_management/view", "refresh");
        }
    }
    //---------------------Product Delete Start--------------------------------//
    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();
        $data['selPdt'] = $this->am->view_product("product", array("id" => $id));
        $selPdt = $this->am->view_product("product", array("id" => $id));
        foreach ($selPdt as $pdt) {
            $ext = $pdt->picture;
        }
        unlink("product/final/product_{$id}.{$ext}");
        unlink("files/product_{$id}.txt");
        $this->am->delete_data("addproduct", array("productid" => $id));
        $this->am->delete_data("comment", array("productid" => $id));
        $this->am->delete_data("productcolor", array("productid" => $id));
        $this->am->delete_data("producttags", array("productid" => $id));
        $this->am->delete_data("productunit", array("productid" => $id));
        $this->am->delete_data("productsize", array("productid" => $id));
        $this->am->delete_data("product", array("id" => $id));
        if ($this->am->delete_data("product", array("id" => $id))) {
            $sdata['msg'] = "Delete Successful";
        } else {
            $sdata['msg'] = "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        redirect(base_url() . "product_management/view", "refresh");
    }
//---------------------Product Delete End--------------------------------//

}

