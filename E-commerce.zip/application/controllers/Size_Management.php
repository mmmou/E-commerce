<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Size_Management extends CI_Controller {
    


    public function index() {
       $data =array();
        $this->load->helper('form');
        $data['title'] = "Size Management";
        $data['content'] = $this->load->view("backend/size-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('size', 'Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper('form');
            $data['title'] = "Size Management";
            $data['content'] = $this->load->view("backend/size-new", $data, TRUE);
            $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("size")
                
            );
            if($this->am->save_data("size", $data)){
             $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "size_management", "refresh");
        }
    }
     public function view(){
        $data = array();
        $data['allSz'] = $this->am->view_data("size", "");
        $data['title'] = "Size View";
        $data['content'] = $this->load->view("backend/size-view", $data, TRUE);
        $this->load->view("master", $data);
    }
     public function edit(){
        $id= $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");
           
        $data['selSiz'] = $this->am->view_data("size", array("id"=>$id));
           
            

            //print_r($data['selSiz']);
            $data['title'] = "Size Management";
            $data['content'] = $this->load->view("backend/size-edit", $data, TRUE);
            $this->load->view("master", $data);
    }
    public function update() {
       
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('size', 'Name', 'required|trim');

       if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper('form');
            $data['title'] = "Size Management";
            $data['content'] = $this->load->view("backend/size-new", $data, TRUE);
            $this->load->view("master", $data);
        }
        else {
            $data = array(
                "name" => $this->input->post("size")
                
            );
            $id =  $this->input->post("id");

            if ($this->am->update_data("size", $data, array("id"=>$id))){
               
                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "size_management/view", "refresh");
        }
    }
    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->am->delete_data("productsize", array("productid" => $id));
        $this->am->delete_data("size", array("id" => $id));
        if ($this->am->delete_data("size", array("id" => $id))) {
            $sdata['msg'] = "Delete Successful";
        } else {
            $sdata['msg'] = "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        redirect(base_url() . "size_management/view", "refresh");
        
    }

}
