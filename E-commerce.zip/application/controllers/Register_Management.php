<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Register_Management extends CI_Controller {

   public function __construct() {
      parent::__construct();
      date_default_timezone_set("Asia/Dhaka");
   }

   public function index() {
      $data = array();
      $this->load->helper("form");
      $data['allCity'] = $this->am->view_data("city", "");
      //print_r($data['allSCat']);
      $data['title'] = "Register Management";
      $data['content'] = $this->load->view("frontend/register", $data, TRUE);
      $this->load->view("master", $data);
   }

   public function insert() {
      $this->load->helper("form");
      $this->load->library('form_validation');

      $this->form_validation->set_rules('name', 'Name', 'required|trim');

      if ($this->form_validation->run() == false) {
         $data = array();
         $this->load->helper("form");
         //print_r($data['allUnit']);
         $data['title'] = "Register Management";
         $data['content'] = $this->load->view("backend/category-new", $data, TRUE);
         $this->load->view("master", $data);
      } else {
         $data = array(
             "name" => $this->input->post("name"),
             "email" => $this->input->post("email"),
             "password" => md5($this->input->post("pass")),
             "contact" => $this->input->post("con"),
             "city" => $this->input->post("city"),
             "date" => date("Y-m-d"),
             "type" => 'c',
             "status" => RandString(12)
         );
         if ($this->am->save_data("customer", $data)) {
            $sdata['msg'] = "Save Successful";
            $msg = "For verify your account, Clic Below Link. <br /><a href='" . base_url() . "register_management/verify/" . $data['status'] . "'>Link</a>";
            mail($data['email'], "Account Verification", $msg);
         } else {
            $sdata['msg'] = "Some error occurs";
         }
         $this->session->set_userdata($sdata);
         redirect(base_url() . "register_management", "refresh");
      }
   }

   public function verify() {
      $data = $this->uri->segment(3);
      if ($data != NULL) {
         $dt = $this->am->view_data("customer", array("status" => $data));
         if ($dt) {
            $this->am->update_data("customer", array("status" => ""), array("status" => $data));
            foreach ($dt as $d) {
               $sdata['id'] = $d->id;
               $sdata['type'] = $d->type;
               $this->session->set_userdata($sdata);
               redirect(base_url(), "refresh");
            }
            echo "Account Verified";
         } else {
            echo "Invalid Code";
         }
      } else {
         echo "Invalid";
      }
   }

}

?>
