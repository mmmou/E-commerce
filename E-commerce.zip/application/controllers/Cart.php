<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {

   public function checkout() {
      $data = array();
      $data['title'] = "Product Summary";
      $data['allCat'] = $this->am->view_data("category", "");
      $data['allSCat'] = $this->am->view_subcategory();
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $pdtid = $this->session->userdata("pdtid");

      $data['selPdt'] = $this->am->checkoutpdt($pdtid);

      $data['content'] = $this->load->view("frontend/product_summary", $data, true);
      $this->load->view("master", $data);
   }

   public function remove() {
      header('Content-Type: application/json');
      $id = $this->input->post("id");
      $pdtid = $this->session->userdata("pdtid");
      $qtyid = $this->session->userdata("qtyid");
      $pPrice = $this->session->userdata("pdtPrice");

      $sdata['qtyid'] = array();
      $sdata['pdtid'] = array();
      for ($i = 0; $i < count($qtyid); $i++) {
         if ($pdtid[$i] != $id) {
            $sdata['qtyid'][] = $qtyid[$i];
            $sdata['pdtid'][] = $pdtid[$i];
         } else {
            $tqty = $qtyid[$i];
         }
      }
      
      if ($sdata['qtyid']) {
         $selPdt = $this->am->productStock($id);
         foreach ($selPdt as $pdt) {
            $price = $pdt->price;
            $dis = $pdt->discount;
            $vat = $pdt->vat;
         }

         $tPrice = Cal($price, $vat, $dis) * $tqty;
         $sdata['pdtPrice'] = $pPrice - $tPrice;


         $jdata['msg'] = "Remove Successful";
         $jdata['sTotal'] = $sdata['pdtPrice'];
      } else {
         $jdata['sTotal'] = 0;
         $sdata['pdtPrice'] = 0;
      }
      $this->session->set_userdata($sdata);
      echo json_encode($jdata);
   }

   public function update() {
      header('Content-Type: application/json');
      $qty = $this->input->post("qty");
      $id = $this->input->post("id");
      $pdtid = $this->session->userdata("pdtid");
      $qtyid = $this->session->userdata("qtyid");
      $pPrice = $this->session->userdata("pdtPrice");

      if ($qty > 0) {
         $selPdt = $this->am->productStock($id);
         foreach ($selPdt as $pdt) {
            $stock = $pdt->stock;
            $apStock = $pdt->apStock;
            $tSell = $pdt->tSell;
            $price = $pdt->price;
            $dis = $pdt->discount;
            $vat = $pdt->vat;
         }
         if (($stock + $apStock) >= ($tSell + $qty)) {
            for ($i = 0; $i < count($qtyid); $i++) {
               if ($pdtid[$i] == $id) {
                  $old_qty = $qtyid[$i];
                  $sdata['qtyid'][] = $qty;
               } else {
                  $sdata['qtyid'][] = $qtyid[$i];
               }
            }
            $qq = $qty - $old_qty;
            $sdata['pdtPrice'] = $pPrice + (Cal($price, $vat, $dis) * $qq);

            $this->session->set_userdata($sdata);
            $jdata['msg'] = "Cart Update Success";
            $jdata['status'] = 1;
            $jdata['sTotal'] = Cal($price, $vat, $dis) * $qty;
            $jdata['price'] = $sdata['pdtPrice'];
         } else {
            $jdata['msg'] = "Out of stock";
            $jdata['status'] = 0;
         }
      } else {
         $jdata['msg'] = "Min mum One Choose";
         $jdata['status'] = 0;
      }
      echo json_encode($jdata);
   }

   public function add_to_cart() {
      header('Content-Type: application/json');
      $qty = $this->input->post("qty");
      $id = $this->input->post("id");
      $pdtid = $this->session->userdata("pdtid");
      $qtyid = $this->session->userdata("qtyid");
      $pPrice = $this->session->userdata("pdtPrice");
      $product = 0;

      if ($pdtid) {
         for ($i = 0; $i < count($qtyid); $i++) {
            $sdata['pdtid'][] = $pdtid[$i];
            $sdata['qtyid'][] = $qtyid[$i];
            if ($pdtid[$i] == $id) {
               $product++;
               break;
            }
         }
      }
      if ($product == 0) {
         if ($qty > 0) {
            $selPdt = $this->am->productStock($id);
            foreach ($selPdt as $pdt) {
               $stock = $pdt->stock;
               $apStock = $pdt->apStock;
               $tSell = $pdt->tSell;
               $price = $pdt->price;
               $dis = $pdt->discount;
               $vat = $pdt->vat;
            }
            if (($stock + $apStock) >= ($tSell + $qty)) {
               $sdata['pdtid'][] = $id;
               $sdata['qtyid'][] = $qty;
               $sdata['pdtPrice'] = $pPrice + (Cal($price, $vat, $dis) * $qty);
               $this->session->set_userdata($sdata);
               $jdata['msg'] = "Procuct added to successful";
               $jdata['price'] = $sdata['pdtPrice'];
               $jdata['status'] = 1;
            } else {
               $jdata['msg'] = "Out of stock";
               $jdata['status'] = 0;
            }
         }
      } else {
         $jdata['msg'] = "Product already in Cart";
         $jdata['status'] = 0;
      }
      echo json_encode($jdata);
   }

}

?>