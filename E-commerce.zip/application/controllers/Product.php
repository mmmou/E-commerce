<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

   public function details() {
      $data = array();
      $id = $this->uri->segment(3);
      $data['title'] = "Home";
      $data['allCat'] = $this->am->view_data("category", "");
      $this->load->helper("form");
      $data['captcha'] = $this->am->MyCaptche();
      $data['allSCat'] = $this->am->view_subcategory();
      $data['selPdt'] = $this->am->product_details($id);
      $data['allCom'] = $this->am->Comment($id);
      $data['selPd'] = $this->am->view_product("product", array("id" => $id));
      echo "<pre>";
      //print_r($data['selPdt']);
      echo "</pre>";
      $data['sidebar'] = $this->load->view("sidebar", $data, true);
      $data['content'] = $this->load->view("frontend/product_details", $data, true);
      $this->load->view("master", $data);
   }

   public function insert_comment() {
      echo $cap = $this->input->post("cap");
      $cap_whrer = array(
          "word" => $cap,
          "time > " => time() - 600
      );
      $r = $this->am->View_Data_for_captcha("captcha", "*", $cap_whrer, "word");
      if($r){
         echo "Valid";
      }
      else{
         echo "Invalid Captcha";
      }
   }

   public function captcha_generator() {
      header('Content-type: application/json');
      $data = $this->am->MyCaptche();
      echo json_encode($data);
   }

}

?>