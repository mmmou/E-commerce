<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

   public function __construct() {
      parent::__construct();
      date_default_timezone_set("Asia/Dhaka");
   }

   public function index() {
      $data = array();
      $this->load->helper("form");
      $data['allCity'] = $this->am->view_data("city", "");
      //print_r($data['allSCat']);
      $data['title'] = "Register Management";
      $data['content'] = $this->load->view("frontend/register", $data, TRUE);
      $this->load->view("master", $data);
   }

   public function check(){
      $data = array(
          "email" => $this->input->post("email"),
          "password" => md5($this->input->post("pass"))
      );
      
      $dt = $this->am->view_data("customer", $data);
      
      if($dt){
         foreach ($dt as $d){
            if($d->status == ""){
               $sdata['id'] = $d->id;
               $sdata['type'] = $d->type;
               $this->session->set_userdata($sdata);
               redirect(base_url(), "refresh");
            }
            else{
               echo "Please verify your account";
            }
         }
      }
      else{
         echo "Invalid Email or Password";
      }
   }
   public function logout(){
      $this->session->sess_destroy();
      redirect(base_url(), "refresh");
   }
}

?>
