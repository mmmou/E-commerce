<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Unit_Management extends CI_Controller {
    


    public function index() {
       $data =array();
        $this->load->helper('form');
        $data['title'] = "Unit Management";
        $data['content'] = $this->load->view("backend/unit-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('unit', 'Name', 'required|trim');

        if ($this->form_validation->run() == false) {
        $data =array();
        $this->load->helper('form');
        $data['title'] = "Unit Management";
        $data['content'] = $this->load->view("backend/unit-new", $data, TRUE);
        $this->load->view("master", $data);
        } else {
            $data = array(
                "name" => $this->input->post("unit")
                
            );
            if($this->am->save_data("unit", $data)){
                 $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "unit_management/", "refresh");
        }
    }
public function view(){
        $data = array();
        $data['allUnit'] = $this->am->view_data("Unit", "");
        $data['title'] = "Unit View";
        $data['content'] = $this->load->view("backend/unit-view", $data, TRUE);
        $this->load->view("master", $data);
    }
    public function edit(){
        $id= $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");
           
        $data['selUnit'] = $this->am->view_data("unit", array("id"=>$id));
           
            

            //print_r($data['selUnit']);
            $data['title'] = "Unit Management";
            $data['content'] = $this->load->view("backend/unit-edit", $data, TRUE);
            $this->load->view("master", $data);
    }
    public function update() {
       
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('unit', 'Name', 'required|trim');

       if ($this->form_validation->run() == false) {
            $data = array();
            $this->load->helper('form');
            $data['title'] = "Unit Management";
            $data['content'] = $this->load->view("backend/unit-new", $data, TRUE);
            $this->load->view("master", $data);
        }
        else {
            $data = array(
                "name" => $this->input->post("unit")
                
            );
            $id =  $this->input->post("id");

            if ($this->am->update_data("unit", $data, array("id"=>$id))){
               
                $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "unit_management/view", "refresh");
        }
    }
    
    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->am->delete_data("productunit", array("productid" => $id));
        $this->am->delete_data("unit", array("id" => $id));
        if ($this->am->delete_data("unit", array("id" => $id))) {
            $sdata['msg'] = "Delete Successful";
        } else {
            $sdata['msg'] = "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        redirect(base_url() . "unit_management/view", "refresh");
        
    }
}
