<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class City_Management extends CI_Controller {

    public function index() {
        $data =array();
        $this->load->helper('form');
        $data['allCnt'] = $this->am->view_data("country", "");
        $data['title'] = "City Management";
        $data['content'] = $this->load->view("backend/city-new", $data, TRUE);
        $this->load->view("master", $data);
    }

    public function insert() {
        $this->load->helper("form");
        $this->load->library('form_validation');

        $this->form_validation->set_rules('ct', 'City', 'required|trim');
        
        $this->form_validation->set_rules('countryid', 'Country', 'required|trim');
        

        if ($this->form_validation->run() == false) {
           $data =array();
            $this->load->helper('form');
            $data['allCnt'] = $this->am->view_data("country", "");
            $data['title'] = "City Management";
            $data['content'] = $this->load->view("backend/city-new", $data, TRUE);
            $this->load->view("master", $data);
        }
        else {
            $data = array(
                "name" => $this->input->post("ct"),
                
                "countryid" => $this->input->post("countryid")
            );
            if($this->am->save_data("city", $data)){
             $sdata['msg'] = "Save Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "city_management", "refresh");
        }
    }
    public function view(){
        $data = array();
        
        $data['allCt'] = $this->am->view_data("city", "");
        $data['allCnt'] = $this->am->view_data("country", "");
        $data['title'] = "City View";
        $data['content'] = $this->load->view("backend/city-view", $data, TRUE);
        $this->load->view("master", $data);
    }
     public function edit(){
        $id= $this->uri->segment(3);
        $data = array();
        $this->load->helper("form");

            $data['selSCty'] = $this->am->view_data("city", array("id"=>$id));
            $data['allCnt'] = $this->am->view_data("country", "");
            
             //print_r($data['selColor']);
            $data['title'] = "City Management";
            $data['content'] = $this->load->view("backend/city-edit", $data, TRUE);
            $this->load->view("master", $data);
    }
    public function update() {
        $this->load->helper("form");
        $this->load->library('form_validation');


       $this->form_validation->set_rules('ct', 'City', 'required|trim');
        
        $this->form_validation->set_rules('countryid', 'Country', 'required|trim');
       

        if ($this->form_validation->run() == FALSE) {
            $data =array();
           $this->load->helper('form');
           $data['allCnt'] = $this->am->view_data("country", "");
           $data['title'] = "City Management";
           $data['content'] = $this->load->view("backend/city-new", $data, TRUE);
           $this->load->view("master", $data);
        } 

        else {
            $data = array(
                "name" => $this->input->post("ct"),
                "countryid" => $this->input->post("countryid")
            );
            $id =  $this->input->post("id");

            if ($this->am->update_data("city", $data, array("id"=>$id))) {                
                 $sdata['msg'] = "Update Successful";
            } else {
                $sdata['msg'] = "Some error occurs";
            }
            $this->session->set_userdata($sdata);
            redirect(base_url() . "city_management/view", "refresh");
        }
    }
    public function delete() {
        $id = $this->uri->segment(3);
        $data = array();
        $this->am->delete_data("city", array("id" => $id));
        if ($this->am->delete_data("city", array("id" => $id))) {
            $sdata['msg'] = "Delete Successful";
        } else {
            $sdata['msg'] = "Some error occurs";
        }
        $this->session->set_userdata($sdata);
        redirect(base_url() . "city_management/view", "refresh");
        
    }
}
