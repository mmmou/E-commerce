<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title><?php if (isset($title)) echo $title; ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <meta name="author" content="">
        <!--Less styles -->
        <!-- Other Less css file //different less files has different color scheam
             <link rel="stylesheet/less" type="text/css" href="<?php echo base_url(); ?>themes/less/simplex.less">
             <link rel="stylesheet/less" type="text/css" href="<?php echo base_url(); ?>themes/less/classified.less">
             <link rel="stylesheet/less" type="text/css" href="<?php echo base_url(); ?>themes/less/amelia.less">  MOVE DOWN TO activate
        -->
        <!--<link rel="stylesheet/less" type="text/css" href="<?php echo base_url(); ?>themes/less/bootshop.less">
        <script src="<?php echo base_url(); ?>themes/js/less.js" type="text/javascript"></script> -->

        <!-- Bootstrap style --> 
        <link id="callCss" rel="stylesheet" href="<?php echo base_url(); ?>themes/bootshop/bootstrap.min.css" media="screen"/>
        <link href="<?php echo base_url(); ?>themes/css/base.css" rel="stylesheet" media="screen"/>
        <!-- Bootstrap style responsive -->	
        <link href="<?php echo base_url(); ?>themes/css/bootstrap-responsive.min.css" rel="stylesheet"/>
        <link href="<?php echo base_url(); ?>themes/css/font-awesome.css" rel="stylesheet" type="text/css">
        <!-- Google-code-prettify -->	
        <link href="<?php echo base_url(); ?>themes/js/google-code-prettify/prettify.css" rel="stylesheet"/>
        <!-- fav and touch icons -->
        <link rel="shortcut icon" href="<?php echo base_url(); ?>themes/images/ico/favicon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url(); ?>themes/images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url(); ?>themes/images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url(); ?>themes/images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="<?php echo base_url(); ?>themes/images/ico/apple-touch-icon-57-precomposed.png">
        <style type="text/css" id="enject"></style>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>themes/css/mystyle.css">
        <script src="<?php echo base_url(); ?>themes/js/jquery.js" type="text/javascript"></script>
    </head>
    <body>
        <div id="header">
            <div class="container">
                <div id="welcomeLine" class="row">
                    <div class="span6">Welcome!<strong> User</strong></div>
                    <div class="span6">
                        <?php
                        
                        $pdtid = $this->session->userdata("pdtid");
                        $qtyid = $this->session->userdata("qtyid");
                        $pPrice = $this->session->userdata("pdtPrice");
                        /*
                        print_r($pdtid);
                        print_r($qtyid);
                        echo $pPrice;
                        */
                        ?>
                        <div class="pull-right">
                            <span class="btn btn-mini" style="font-size: 17px; padding: 3px;" ><span style="font-size: 17px;">৳ </span><span id="totalPrice"><?php echo $pPrice ?></span></span>
                            <a href="<?php echo base_url(); ?>cart/checkout"><span class="btn btn-mini btn-primary" style="font-size: 17px; padding: 3px;"><i class="icon-shopping-cart icon-white"></i> [ <span id="totalItem"><?php echo count($pdtid); ?></span> ] Itemes in your cart </span> </a> 
                        </div>
                    </div>
                </div>
                <!-- Navbar ================================================== -->
                <div id="logoArea" class="navbar">
                    <a id="smallScreen" data-target="#topMenu" data-toggle="collapse" class="btn btn-navbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-inner">
                        <a class="brand" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>themes/images/logo.png" alt="Bootsshop"/></a>
                        <form class="form-inline navbar-search" method="post" action="products" >
                            <input id="srchFld" class="srchTxt" type="text" />
                            <select class="srchTxt">
                                <option>All</option>
                                <option>CLOTHES </option>
                                <option>FOOD AND BEVERAGES </option>
                                <option>HEALTH & BEAUTY </option>
                                <option>SPORTS & LEISURE </option>
                                <option>BOOKS & ENTERTAINMENTS </option>
                            </select> 
                            <input type="submit" id="submitButton" class="btn btn-primary" />
                        </form>
                        <ul id="topMenu" class="nav pull-right">
                           
                           <?php
                              $type = $this->session->userdata("type");
                              if($type != NULL){
                                 ?>
                                 <li class=""><a href="<?php echo base_url(); ?>report">Report</a></li>
                            <?php
                              }
                              else{
                              ?>
                              
                            <?php
                              }
                            ?>
                           
                           
                          
                            <li class=""><a href="<?php echo base_url(); ?>nhclc/special_offer">Specials Offer</a></li>
                            <li class=""><a href="<?php echo base_url(); ?>nhclc/delivery">Delivery</a></li>
                            <li class=""><a href="<?php echo base_url(); ?>nhclc/contact">Contact</a></li>
                            <?php
                              $type = $this->session->userdata("type");
                              if($type != NULL){
                                 ?>
                                 <li class=""><a href="<?php echo base_url(). "login/logout"; ?>"><span class="btn btn-large btn-success">Logout</span></a></li>
                            <?php
                              }
                              else{
                              ?>
                              <li class="">
                                <a href="#login" role="button" data-toggle="modal" style="padding-right:0"><span class="btn btn-large btn-success">Login</span></a>
                                <div id="login" class="modal hide fade in" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="false" >
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                        <h3>Login Block</h3>
                                    </div>
                                    <div class="modal-body">
                                       <form action="<?php echo base_url() ?>login/check" method="post" class="form-horizontal loginFrm">
                                            <div class="control-group">								
                                                <input type="text" name="email" id="inputEmail" placeholder="Email">
                                            </div>
                                            <div class="control-group">
                                                <input type="password" name="pass" id="inputPassword" placeholder="Password">
                                            </div>
                                            <div class="control-group">
                                                <label class="checkbox">
                                                    <input type="checkbox"> Remember me
                                                </label>
                                            </div>
                                          <input type="submit" id="submitButton" class="btn btn-primary" />
                                        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
                                        </form>		
                                        
                                    </div>
                                </div>
                            </li>
                            <?php
                              }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
       <?php
         if($type == 'e' || $type == 'a'){
       ?>
        <!--Dropdown-->
        <div class="container ">
            <div class="dropdown pull-right">
                <button class="btn btn-default dropdown-toggle" type="button" data-toggle="dropdown">Admin Panel
                    <span class="caret"></span>
                </button>

                <ul class="dropdown-menu">
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Product</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>product_management/view">View</a></li>
                            <li><a href="<?php echo base_url(); ?>product_management">Add New</a></li>
                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Add Product</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>add_product_management"> Add New Product</a></li>
                            <li><a href="<?php echo base_url(); ?>add_product_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="">Category</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>category_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>category_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="">Subcategory</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>subcategory_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>subcategory_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Country</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>country_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>country_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">City</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>city_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>city_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Color</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>color_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>color_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Size</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>size_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>size_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Tags</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>tags_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>tags_management/view">View</a></li>

                        </ul>
                    </li>
                    <li class="dropdown-submenu pull-left">
                        <a class="test" href="#">Unit</a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>unit_management"> Add New</a></li>
                            <li><a href="<?php echo base_url(); ?>unit_management/view">View</a></li>

                        </ul>
                    </li>

                </ul>
            </div>
        </div>
        <?php
         }
        ?>
        <!--Dropdown end-->
        <!-- Header End====================================================================== -->


        <?php
        if (isset($content)) {
            echo $content;
        }
        ?>


        <!-- Footer ================================================================== -->
        <div  id="footerSection">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <h5>ACCOUNT</h5>
                        <a href="<?php echo base_url(); ?>nhclc/login">YOUR ACCOUNT</a>
                        <a href="<?php echo base_url(); ?>nhclc/login">PERSONAL INFORMATION</a> 
                        <a href="<?php echo base_url(); ?>nhclc/login">ADDRESSES</a> 
                        <a href="<?php echo base_url(); ?>nhclc/login">DISCOUNT</a>  
                        <a href="<?php echo base_url(); ?>nhclc/login">ORDER HISTORY</a>
                    </div>
                    <div class="span3">
                        <h5>INFORMATION</h5>
                        <a href="<?php echo base_url(); ?>nhclc/contact">CONTACT</a>  
                        <a href="<?php echo base_url(); ?>nhclc/register">REGISTRATION</a>  
                        <a href="<?php echo base_url(); ?>nhclc/legal_notice">LEGAL NOTICE</a>  
                        <a href="<?php echo base_url(); ?>nhclc/tac">TERMS AND CONDITIONS</a> 
                        <a href="<?php echo base_url(); ?>nhclc/faq">FAQ</a>
                    </div>
                    <div class="span3">
                        <h5>OUR OFFERS</h5>
                        <a href="<?php echo base_url(); ?>nhclc/#">NEW PRODUCTS</a> 
                        <a href="<?php echo base_url(); ?>nhclc/#">TOP SELLERS</a>  
                        <a href="<?php echo base_url(); ?>nhclc/special_offer">SPECIAL OFFERS</a>  
                        <a href="<?php echo base_url(); ?>nhclc/#">MANUFACTURERS</a> 
                        <a href="<?php echo base_url(); ?>nhclc/#">SUPPLIERS</a> 
                    </div>
                    <div id="socialMedia" class="span3 pull-right">
                        <h5>SOCIAL MEDIA </h5>
                        <a href="<?php echo base_url(); ?>nhclc/#"><img width="60" height="60" src="<?php echo base_url(); ?>themes/images/facebook.png" title="facebook" alt="facebook"/></a>
                        <a href="<?php echo base_url(); ?>nhclc/#"><img width="60" height="60" src="<?php echo base_url(); ?>themes/images/twitter.png" title="twitter" alt="twitter"/></a>
                        <a href="<?php echo base_url(); ?>nhclc/#"><img width="60" height="60" src="<?php echo base_url(); ?>themes/images/youtube.png" title="youtube" alt="youtube"/></a>
                    </div> 
                </div>
                <p class="pull-right">&copy; Bootshop</p>
            </div><!-- Container End -->
        </div>
        <!-- Placed at the end of the document so the pages load faster ============================================= -->

        <script src="<?php echo base_url(); ?>themes/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>themes/js/google-code-prettify/prettify.js"></script>

        <script src="<?php echo base_url(); ?>themes/js/bootshop.js"></script>
        <script src="<?php echo base_url(); ?>themes/js/jquery.lightbox-0.5.js"></script>

        <!-- Themes switcher section ============================================================================================= -->
        <div id="secectionBox">
            <link rel="stylesheet" href="<?php echo base_url(); ?>themes/switch/themeswitch.css" type="text/css" media="screen" />
            <script src="<?php echo base_url(); ?>themes/switch/theamswitcher.js" type="text/javascript" charset="utf-8"></script>
            <div id="themeContainer">
                <div id="hideme" class="themeTitle">Style Selector</div>
                <div class="themeName">Oregional Skin</div>
                <div class="images style">
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="bootshop"><img src="<?php echo base_url(); ?>themes/switch/images/clr/bootshop.png" alt="bootstrap business templates" class="active"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="businessltd"><img src="<?php echo base_url(); ?>themes/switch/images/clr/businessltd.png" alt="bootstrap business templates" class="active"></a>
                </div>
                <div class="themeName">Bootswatch Skins (11)</div>
                <div class="images style">
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="amelia" title="Amelia"><img src="<?php echo base_url(); ?>themes/switch/images/clr/amelia.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="spruce" title="Spruce"><img src="<?php echo base_url(); ?>themes/switch/images/clr/spruce.png" alt="bootstrap business templates" ></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="superhero" title="Superhero"><img src="<?php echo base_url(); ?>themes/switch/images/clr/superhero.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="cyborg"><img src="<?php echo base_url(); ?>themes/switch/images/clr/cyborg.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="cerulean"><img src="<?php echo base_url(); ?>themes/switch/images/clr/cerulean.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="journal"><img src="<?php echo base_url(); ?>themes/switch/images/clr/journal.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="readable"><img src="<?php echo base_url(); ?>themes/switch/images/clr/readable.png" alt="bootstrap business templates"></a>	
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="simplex"><img src="<?php echo base_url(); ?>themes/switch/images/clr/simplex.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="slate"><img src="<?php echo base_url(); ?>themes/switch/images/clr/slate.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="spacelab"><img src="<?php echo base_url(); ?>themes/switch/images/clr/spacelab.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="united"><img src="<?php echo base_url(); ?>themes/switch/images/clr/united.png" alt="bootstrap business templates"></a>
                    <p style="margin:0;line-height:normal;margin-left:-10px;display:none;"><small>These are just examples and you can build your own color scheme in the backend.</small></p>
                </div>
                <div class="themeName">Background Patterns </div>
                <div class="images patterns">
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern1"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern1.png" alt="bootstrap business templates" class="active"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern2"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern2.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern3"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern3.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern4"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern4.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern5"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern5.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern6"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern6.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern7"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern7.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern8"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern8.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern9"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern9.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern10"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern10.png" alt="bootstrap business templates"></a>

                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern11"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern11.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern12"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern12.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern13"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern13.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern14"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern14.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern15"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern15.png" alt="bootstrap business templates"></a>

                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern16"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern16.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern17"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern17.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern18"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern18.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern19"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern19.png" alt="bootstrap business templates"></a>
                    <a href="<?php echo base_url(); ?>nhclc/<?php echo base_url(); ?>themes/css/#" name="pattern20"><img src="<?php echo base_url(); ?>themes/switch/images/pattern/pattern20.png" alt="bootstrap business templates"></a>

                </div>
            </div>
        </div>
        <span id="themesBtn"></span>
    </body>
    <script src="http://cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>tinymce.init({selector: 'textarea'});</script>
    <script>
        $(document).ready(function() {
            $('.dropdown-submenu a.test').on("click", function(e) {
                $(this).next('ul').toggle();
                e.stopPropagation();
                e.preventDefault();
            });
        });
    </script>

</html>