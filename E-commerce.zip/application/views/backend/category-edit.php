<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Category</h1>
        <hr class="soften"/>
        <?php 
        
            
            echo validation_errors();
        
        
            foreach ($selCat as $scat) {
            	
         //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => ""
        );
        $hid = array("id"=>$scat->id);
        echo form_open(base_url() . "category_management/update", $data, $hid);
        //Category Title
        echo '<div class="control-group">';
        //Category Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
         echo form_label("Category Name", "", $data);
        echo '<div class="controls">';
        //Category title input
        $data = array(
            "name" => "cat",
            "placeholder" => "Category Name",
            "value" => $scat->name,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close

                  
        //Submit start  
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
        }
        //form close
        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->
