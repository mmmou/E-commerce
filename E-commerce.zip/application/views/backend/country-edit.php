<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Country</h1>
        <hr class="soften"/>
        <?php 
        
            
            echo validation_errors();
        
        
            foreach ($selCnt as $cnt) {
                
                
         //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$cnt->id);
        echo form_open(base_url() . "country_management/update", $data, $hid);
        //Country Title
        echo '<div class="control-group">';
        //Country Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
         echo form_label("Country Name", "", $data);
        echo '<div class="controls">';
        //Country title input
        $data = array(
            "name" => "cnt",
            "placeholder" => "Country Name",
            "value" => $cnt->name,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close

                  
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
        }
        //form close
        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->
