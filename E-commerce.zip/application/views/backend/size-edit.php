<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Size</h1>
        <hr class="soften"/>
        <?php 
        
            
            echo validation_errors();
        
        
            foreach ($selSiz as $ssz) {
                
                
         //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$ssz->id);
        echo form_open(base_url() . "size_management/update", $data, $hid);
        //Size Title
        echo '<div class="control-group">';
        //Size Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
         echo form_label("Size Name", "", $data);
        echo '<div class="controls">';
        //Size title input
        $data = array(
            "name" => "size",
            "placeholder" => "Size Name",
            "value" => $ssz->name,
            "required"=>"required"

        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close

                  
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
        }
        //form close
        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->
