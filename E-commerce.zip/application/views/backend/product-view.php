<div id="mainBody">
    <div class="container">
        <div class="row">
            <div class="span12">
                <h3>View/Edit/Update/Delete Product</h3>
                <?php
                $msg = $this->session->userdata("msg");
                if ($msg != NULL) {
                    echo '<div class="alert alert-success alert-dismissible" role="alert">';
                    echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
                    echo $msg;
                    echo "</div>";
                    $this->session->unset_userdata("msg");
                }
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Picture</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th>Date</th>
                            <th>Unitid</th>
                            <th>Subcategory</th>
                            <th>Category</th>
                            <th>Tags</th>
                            <th>Size</th>
                            <th>Color</th>
                            <th>Discount</th>
                            <th>Vat</th>
                            <th>Modify</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($allPdt as $pdt) {
                            ?>
                            <tr>
                                <td><?php echo $pdt->id; ?></td>
                                <td> <img width="60" src="<?php echo base_url() . "product/final/product_{$pdt->id}.{$pdt->picture}" ?>" alt=""/></td>
                                <td><?php echo $pdt->title; ?></td>
                                <td><?php echo $pdt->price; ?></td>
                                <td><?php echo $pdt->date; ?></td>
                                <td><?php
                                    foreach ($allUnit as $unt) {
                                        if (($pdt->unitid) == ($unt->id))
                                            echo $unt->name;
                                    }
                                    ?>
                                </td>
                                <td>

                                    <?php
                                    foreach ($allSCat as $scat) {
                                        if (($pdt->subcategoryid) == ($scat->id)) {
                                            echo $scat->name;
                                        }
                                    }
                                    ?>

                                </td>
                                <td>
                                    <?php
                                    foreach ($allSCat as $scat) {
                                        foreach ($allCat as $cat) {
                                            if (($pdt->subcategoryid) == ($scat->id)) {
                                                if (($cat->id) == ($scat->categoryid)) {
                                                    echo $cat->name;
                                                }
                                            }
                                        }
                                    }
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    foreach ($allsTags as $tags) {
                                        foreach ($allspdTags as $pdtags) {
                                            if (($pdt->id) == ($pdtags->productid)) {
                                                if (($tags->id) == ($pdtags->tagsid)) {
                                                    echo $tags->name . "<br/>";
                                                }
                                            }
                                        }
                                    }
                                    ?>
                                </td>
                                <td>

                                    <?php
                                    foreach ($allsSize as $size) {
                                        foreach ($allpdSize as $pdsize) {
                                            if (($pdt->id) == ($pdsize->productid)) {
                                                if (($size->id) == ($pdsize->sizeid)) {
                                                    echo $size->name . "<br/>";
                                                }
                                            }
                                        }
                                    }
                                    ?>
                                </td>
                                <td>

                                    <?php
                                    foreach ($allsColor as $color) {
                                        foreach ($allspdColor as $pdcolor) {
                                            if (($pdt->id) == ($pdcolor->productid)) {
                                                if (($color->id) == ($pdcolor->colorid)) {
                                                    echo $color->name . "<br/>";
                                                }
                                            }
                                        }
                                    }
                                    ?>

                                </td>
                                <td><?php echo $pdt->discount; ?> %</td>
                                <td><?php echo $pdt->vat; ?> %</td>
                                <td>
                                    <a href="<?php echo base_url() . "product_management/edit/{$pdt->id}" ?>">
                                        <button class="btn" type="button">
                                            <i class="icon-edit"></i> Edit</button>
                                    </a>

                                    <a href="<?php echo base_url() . "product_management/delete/{$pdt->id}" ?>">
                                        <button class="btn" type="button">
                                            <i class="icon-remove"></i>Delete
                                        </button>
                                </td>
                            </tr>



                            <?php
                        }
                        ?>
                    </tbody>
                </table>


            </div>
        </div></div>
</div>