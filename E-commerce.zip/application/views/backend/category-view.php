<div id="mainBody">
    <div class="container">
        <div class="row">
            <div class="span7">
                <h3>View/Edit/Update/Delete Category</h3>
                <?php
                $msg = $this->session->userdata("msg");
                if ($msg != NULL) {
                    echo '<div class="alert alert-success alert-dismissible" role="alert">';
                    echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
                    echo $msg;
                    echo "</div>";
                    $this->session->unset_userdata("msg");
                }
                ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>

                            <th>Modify</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($allCat as $cat) {
                            ?>
                            <tr>
                                <td><?php echo $cat->id; ?></td>
                                <td><?php echo $cat->name; ?></td>
                                <td>
                                    <a href="<?php echo base_url() . "category_management/edit/{$cat->id}" ?>">
                                        <button class="btn" type="button">
                                            <i class="icon-edit"></i> Edit</button>
                                    </a>

                                    <a href="<?php echo base_url() . "category_management/delete/{$cat->id}" ?>">
                                        <button class="btn" type="button">
                                            <i class="icon-remove"></i>Delete
                                        </button>
                                </td>


                            </tr>

                            <?php
                        }
                        ?>
                    </tbody>
                </table>


            </div>
        </div></div>
</div>