<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>New Subcategory</h1>
        <hr class="soften"/>



        <?php
        $msg = $this->session->userdata("msg");
        if ($msg != NULL) {
            echo '<div class="alert alert-success alert-dismissible" role="alert">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            echo $msg;
            echo "</div>";
            $this->session->unset_userdata("msg");
        }
        echo Validation_errors();

        $data = array(
            "class" => "form-horizontal",
            "id" => "TestId"
        );
        echo form_open(base_url() . "subcategory_management/insert", $data);

        //Subcategory New
        echo '<div class="control-group">';
        //Label Start

        $data = array("class" => "control-label");
        echo form_label("Subcategory Name", "", $data);

        echo '<div class="controls">';
        $data = array(
            "name" => "scat",
            "placeholder" => "Subcategory Name",
            "value" => set_value('scat')
        );
        echo form_input($data);
        echo "</div>";
        echo "</div>";

        //Category
        echo '<div class="control-group">';
        //Label Start

        $data = array("class" => "control-label");
        echo form_label("Category", "", $data);

        echo '<div class="controls">';
        $data = array();
        $data[0] = "Choose Catagory";
        foreach ($allCat as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("catid", $data, "", array("id" => "catid"));
        echo "</div>";
        echo "</div>";





//Submit Button
        echo '<div class="control-group">';


        echo '<div class="controls">';
        $data = array(
            "name" => "sub",
            "value" => "submit",
            "class" => "btn btn-large btn-success"
        );
        echo form_submit($data);
        echo "</div>";
        echo "</div>";







        echo form_close();
        ?>




    </div></div>
