<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit City</h1>
        <hr class="soften"/>
        <?php 
        
           
        foreach ($selSCty as $scat) {
            		
            //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$scat->id);
        echo form_open(base_url() . "city_management/update", $data, $hid);
       
        //City Name
        echo '<div class="control-group">';
        //City Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
        echo form_label("City", "", $data);
        echo '<div class="controls">';
        //City title input
        $data = array(
            "name" => "ct",
            "placeholder" => "City",
            "value" => $scat->name,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close	

         //Country Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Country", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allCnt as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("countryid", $data, $scat->countryid);

        echo '</div>';
        echo '</div>';
        //Country Close


        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
      
        
        //form close


       

        echo form_close();


                }
        
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->

 