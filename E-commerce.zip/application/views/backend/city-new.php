<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>New Product</h1>
        <hr class="soften"/>



        <?php
        $msg = $this->session->userdata("msg");
        if ($msg != NULL) {
            echo '<div class="alert alert-success alert-dismissible" role="alert">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            echo $msg;
            echo "</div>";
            $this->session->unset_userdata("msg");
        }

        echo validation_errors();

        $data = array(
            "class" => "form-horizontal",
            "id" => "TestId"
        );
        echo form_open(base_url() . "city_management/insert", $data);

//New City
        echo '<div class="control-group">';
        //Label Start

        $data = array("class" => "control-label");
        echo form_label("City Name", "", $data);

        echo '<div class="controls">';
        $data = array(
            "name" => "ct",
            "placeholder" => "City Name",
            "value" => set_value("ct")
        );
        echo form_input($data);
        echo "</div>";
        echo "</div>";


//Country
        echo '<div class="control-group">';
        //Label Start

        $data = array(
            "class" => "control-label"
        );
        echo form_label("Country", "", $data);

        echo '<div class="controls">';
        $data = array();
        $data [0] = "Choose Country";
        foreach ($allCnt as $cnt) {
            $data[$cnt->id] = $cnt->name;
        }

        echo form_dropdown("countryid", $data);
        echo "</div>";
        echo "</div>";



//Submit Button
        echo '<div class="control-group">';


        echo '<div class="controls">';
        $data = array(
            "name" => "sub",
            "value" => "submit",
            "class" => "btn btn-large btn-success"
        );
        echo form_submit($data);
        echo "</div>";
        echo "</div>";







        echo form_close();
        ?>



    </div></div>
