<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Product</h1>
        <hr class="soften"/>
        <?php 
        
            $msg = $this->session->userdata("msg");
            if($msg != NULL){
                echo '<div class="alert alert-success">';
                echo $msg;
                echo "</div>";
                $this->session->unset_userdata("msg");
            }
            echo validation_errors();
        
        
            foreach ($selPdt as $pdt) {
            	foreach ($allSCat as $scat) {
            		if($scat->id == $pdt->subcategoryid){
            			$categoryid = $scat->categoryid;
            			//echo "$categoryid";
            		}
            	}
            	
         //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$pdt->id);
        echo form_open(base_url() . "product_management/update", $data, $hid);
       
        //Product Title
        echo '<div class="control-group">';
        //Product Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
        echo form_label("Product Title", "", $data);
        echo '<div class="controls">';
        //Product title input
        $data = array(
            "name" => "title",
            "placeholder" => "Product Title",
            "value" => $pdt->title,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close


        //Discription Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Disctiption", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "descr",
            "value" =>Read_file ("./files/product_{$pdt->id}.txt"),
        );
        echo form_textarea($data);
        echo '</div>';
        echo '</div>';
        //Discription Close


        

        //Product price
        echo '<div class="control-group">';
        //price label
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Price", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "price",
            "value" => $pdt->price,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Price Close


        //Unit Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Unit", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allUnit as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("unitid", $data, $pdt->unitid);
        echo '</div>';
        echo '</div>';
        //Unit Close


        //stock start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Stock", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "stock",
            "placeholder" => "Stock",
            "value"=>$pdt->stock,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //stock close


        //vat start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Vat", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "vat",
            "placeholder" => "Vat",
            "value"=>$pdt->vat,
            "required"=>"required"
        );
        echo form_input($data);

        echo '</div>';
        echo '</div>';
        //Vat close


        //Discount closs
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Discount", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "discount",
            "placeholder" => "Discount",
            "value"=>$pdt->discount,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Discount close


        //Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Catagory", "", $data);
        echo '<div class="controls">';
        $data = array();
        $data[0] = "Select Category";
        foreach ($allCat as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("catid", $data,$categoryid, array("id" => "catid"));
        echo '</div>';
        echo '</div>';
        //Catagory Close


        //Sub Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Sub Catagory", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allSCat as $dt) {
        	if($dt->categoryid == $categoryid){
            $data[$dt->id] = $dt->name;
            }
        }

        echo form_dropdown("scatid", $data, $pdt->subcategoryid, array("id" => "scatid"));
        echo '</div>';
        echo '</div>';
        //Sub Catagory Close


        //Tags Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Tags", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allTags as $dt) {
            $data[$dt->id] = $dt->name;
        }
        $edata=array();
            foreach ($selTags as $dt) {
                $edata[] = $dt->tagsid;
            }
         echo form_dropdown("tagsid[]", $data, $edata, array("id" => "tagsid", "multiple" => "multiple"));
        echo '</div>';
        echo '</div>';
        //Tags Close


        
        //Color Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Color", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allColors as $dt) {
            $data[$dt->id] = $dt->name;
        }
        $edata = array();
        foreach ($selColor as $dt) {
            $edata[] = $dt->colorid;
        }
        echo form_dropdown("colorid[]", $data, $edata, array("id" => "colorid", "multiple" => "multiple"));
        echo '</div>';
        echo '</div>';
        //Color Close


        
        //Size Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Size", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allSize as $sz) {
            $data[$sz->id] = $sz->name;
        }
        $edata=array();
            foreach ($selSize as $dt) {
                $edata[] = $dt->sizeid;
            }
            echo form_dropdown("sizeid[]", $data, $edata, array("id" => "sizeid", "multiple" => "multiple"));
            echo '</div>';
            echo '</div>';
        //Size Close


        
        //Product Picture
        echo '<div class="control-group">';
        //Product Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
        );
        echo form_label("Product Picture", "", $data);
        echo '<div class="controls">';
        //Product title input
        $data = array(
            "name" => "pic"
        );
        echo form_upload($data);
        echo '</div>';
        echo '</div>';
        //title Close


                  
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
      
        }

        //form close


       

        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->

<link href="<?php echo base_url() ?>bootstrap/css/bootstrap-multiselect.css"
      rel="stylesheet" type="text/css" />
<script src="<?php echo base_url() ?>bootstrap/js/bootstrap-multiselect.js"
type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
        $('#tagsid, #colorid, #sizeid').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<script>
    $(document).ready(function() {
        $("#catid").change(function() {
            var catid = $(this).val();
            var list = "";
<?php
foreach ($allCat as $cat) {
    echo "if (catid == $cat->id) {";
    foreach ($allSCat as $scat) {
        if ($scat->categoryid == $cat->id) {
            echo " list += \"<option value='" . $scat->id . "'>$scat->name</option>\";";
        }
    }
    echo "}";
}
?>
            $("#scatid").html(list);
        });
    });
</script>