<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>New Color</h1>
        <hr class="soften"/>



        <?php
        $msg = $this->session->userdata("msg");
        if ($msg != NULL) {
            echo '<div class="alert alert-success alert-dismissible" role="alert">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            echo $msg;
            echo "</div>";
            $this->session->unset_userdata("msg");
        }

        echo validation_errors();
        $data = array(
            "class" => "form-horizontal",
            "id" => "TestId"
        );
        echo form_open(base_url() . "color_management/insert", $data);

        //Color New
        echo '<div class="control-group">';
        //Label Start

        $data = array("class" => "control-label");
        echo form_label("New Color", "", $data);

        echo '<div class="controls">';
        $data = array(
            "name" => "color",
            "placeholder" => "Color",
            "value" => set_value("color")
        );
        echo form_input($data);
        echo "</div>";
        echo "</div>";
//Submit Button
        echo '<div class="control-group">';


        echo '<div class="controls">';
        $data = array(
            "name" => "sub",
            "value" => "submit",
            "class" => "btn btn-large btn-success"
        );
        echo form_submit($data);
        echo "</div>";
        echo "</div>";







        echo form_close();
        ?>




    </div></div>
