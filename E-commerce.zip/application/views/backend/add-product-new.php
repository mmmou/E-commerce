<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>New Product</h1>
        <hr class="soften"/>
        <?php 
        
            $msg = $this->session->userdata("msg");
            if($msg != NULL){
                echo '<div class="alert alert-success">';
                echo $msg;
                echo "</div>";
                $this->session->unset_userdata("msg");
            }
            echo validation_errors();
        
        //Form Start
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        echo form_open(base_url() . "add_product_management/insert", $data);
        


        //Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Catagory", "", $data);
        echo '<div class="controls">';
        $data = array(

            );
        $data[0] = "Select Category";
        foreach ($allCat as $dt) {
            $data[$dt->id] = $dt->name;
        }

        echo form_dropdown("catid", $data, "",array("id" => "catid", "class"=>"btn btn-default dropdown-toggle") );
        echo '</div>';
        echo '</div>';
        //Catagory Close
    

        //Sub Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Sub Catagory", "", $data);
        echo '<div class="controls">';
        $data = array();
        $data[0] = "Choose Category";
        echo form_dropdown("scatid", $data, "", array("id" => "scatid", "class"=>"btn btn-default dropdown-toggle"));
        echo '</div>';
        echo '</div>';
        //Sub Catagory Close

        //Product Name
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Product", "", $data);
        echo '<div class="controls">';
        $data = array();
        $data[0] = "Choose Sub Category";
        echo form_dropdown("pdtid", $data, "", array("id" => "pdtid", "class"=>"btn btn-default dropdown-toggle"));
        echo '</div>';
        echo '</div>';
        //Product Name

        //stock start
        echo '<div class="control-group">';
          //Label Start
          
          $data = array("class" => "control-label" );
          echo form_label("Add Stock", "", $data);
          
          echo '<div class="controls">';
          $data = array(
              "name" => "astock",
              "placeholder" => "Stock",
              "value" => set_value("astock")
              );
          echo form_input($data);
          echo "</div>";
          echo "</div>";




        //stock close
            
     
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end


        //form close
        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->

<link href="<?php echo base_url() ?>bootstrap/css/bootstrap-multiselect.css"
      rel="stylesheet" type="text/css" />
<script src="<?php echo base_url() ?>bootstrap/js/bootstrap-multiselect.js"
type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
        $('#tagsid, #colorid, #sizeid').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<script>
    $(document).ready(function() {
        $("#catid").change(function() {
            var catid = $(this).val();
            var list = "";
<?php
foreach ($allCat as $cat) {
    echo "if (catid == $cat->id) {";
    echo " list += \"<option value='0'>Choose Sub Category</option>\";";
    foreach ($allSCat as $scat) {
        if ($scat->categoryid == $cat->id) {
            echo " list += \"<option value='" . $scat->id . "'>$scat->name</option>\";";
        }
    }
    echo "}";
}
?>
            $("#scatid").html(list);
        });
    });
</script>







<script>
    $(document).ready(function() {
        $("#scatid").change(function() {
            var scatid = $(this).val();
            var list = "";
<?php
foreach ($allSCat as $scat) {
    echo "if (scatid == $scat->id) {";
    
    foreach ($allPdt as $pdt) {
        if ($scat->id == $pdt->subcategoryid) {
            echo " list += \"<option value='" . $pdt->id . "'>$pdt->title</option>\";";
        }
    }
    echo "}";
}
?>
          $("#pdtid").html(list);   
        });
    });
</script>

     