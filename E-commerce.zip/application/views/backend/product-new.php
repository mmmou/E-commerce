<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>New Product</h1>
        <hr class="soften"/>
        <?php
        $msg = $this->session->userdata("msg");
        if ($msg != NULL) {
            echo '<div class="alert alert-success alert-dismissible" role="alert">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
            echo $msg;
            echo "</div>";
            $this->session->unset_userdata("msg");
        }
        echo validation_errors();

        //Form Start
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        echo form_open(base_url() . "product_management/insert", $data);

        //Product Title
        echo '<div class="control-group">';
        //Product Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
        );
        echo form_label("Product Title", "", $data);
        echo '<div class="controls">';
        //Product title input
        $data = array(
            "name" => "title",
            "placeholder" => "Product Title",
            "value" => set_value("title")
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close
        //Discription Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Disctiption", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "descr",
            "value" => set_value("descr")
        );
        echo form_textarea($data);
        echo '</div>';
        echo '</div>';
        //Discription Close
        //Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Catagory", "", $data);
        echo '<div class="controls">';
        $data = array(
        );
        $data[0] = "Select Category";
        foreach ($allCat as $dt) {
            $data[$dt->id] = $dt->name;
        }

        echo form_dropdown("catid", $data, "", array("id" => "catid", "class" => "btn btn-default dropdown-toggle"));
        echo '</div>';
        echo '</div>';
        //Catagory Close
        //Sub Catagory Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Sub Catagory", "", $data);
        echo '<div class="controls">';
        $data = array();
        $data[0] = "Choose Sub category first";
        echo form_dropdown("scatid", $data, "", array("id" => "scatid", "class" => "btn btn-default dropdown-toggle"));
        echo '</div>';
        echo '</div>';
        //Sub Catagory Close
        //Color Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Color", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allColors as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("colorid[]", $data, "", array("id" => "colorid", "multiple" => "multiple"));
        echo '</div>';
        echo '</div>';
        //Color Close 
        //Size Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Size", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allSize as $sz) {
            $data[$sz->id] = $sz->name;
        }
        echo form_dropdown("sizeid[]", $data, "", array("id" => "sizeid", "multiple" => "multiple"));
        echo '</div>';
        echo '</div>';
        //Size Close
        //Unit Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Unit", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allUnit as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("unitid", $data, "", array("class" => "btn btn-default dropdown-toggle"));
        echo '</div>';
        echo '</div>';
        //Unit Close        
        //Product price
        echo '<div class="control-group">';
        //price label
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Price", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "price",
            "placeholder" => "Price"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Price Close
        //stock start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Stock", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "stock",
            "placeholder" => "Stock"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //stock closs
        //vat start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Vat", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "vat",
            "placeholder" => "Vat"
        );
        echo form_input($data);

        echo '</div>';
        echo '</div>';
        //Vat closs
        //Discount closs
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Discount", "", $data);
        echo '<div class="controls">';
        $data = array(
            "name" => "discount",
            "placeholder" => "Discount"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Discount closs
        //Tags Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Tags", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allTags as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("tagsid[]", $data, "", array("id" => "tagsid", "multiple" => "multiple"));
        echo '</div>';
        echo '</div>';
        //Tags Close  
        //Product Picture
        echo '<div class="control-group">';
        //Picture Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
        );
        echo form_label("Picture", "", $data);
        echo '<div class="controls">';
        //Picture title input
        $data = array(
            "name" => "pic"
        );
        echo form_upload($data);
        echo '</div>';
        echo '</div>';
        //Picture Close
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
        //form close
        echo form_close();
        ?>
    
    </div>
</div>
<!-- MainBody End ============================= -->

<link href="<?php echo base_url() ?>bootstrap/css/bootstrap-multiselect.css"
      rel="stylesheet" type="text/css" />
<script src="<?php echo base_url() ?>bootstrap/js/bootstrap-multiselect.js"
type="text/javascript"></script>
<script type="text/javascript">
    $(function() {
        $('#tagsid, #colorid, #sizeid').multiselect({
            includeSelectAllOption: true
        });
    });
</script>
<script>
    $(document).ready(function() {
        $("#catid").change(function() {
            var catid = $(this).val();
            var list = "";
<?php
foreach ($allCat as $cat) {
    echo "if (catid == $cat->id) {";
    foreach ($allSCat as $scat) {
        if ($scat->categoryid == $cat->id) {
            echo " list += \"<option value='" . $scat->id . "'>$scat->name</option>\";";
        }
    }
    echo "}";
}
?>
            $("#scatid").html(list);
        });
    });
</script>