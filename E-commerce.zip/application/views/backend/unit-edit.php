<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Unit</h1>
        <hr class="soften"/>
        <?php 
        
            
            echo validation_errors();
        
        
            foreach ($selUnit as $unit) {
                
                
         //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$unit->id);
        echo form_open(base_url() . "Unit_management/update", $data, $hid);
        //Unit Title
        echo '<div class="control-group">';
        //Unit Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
         echo form_label("Unit Name", "", $data);
        echo '<div class="controls">';
        //Unit title input
        $data = array(
            "name" => "unit",
            "placeholder" => "Unit Name",
            "value" => $unit->name,
            "required"=>"required"

        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close

                  
        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
        }
        //form close
        echo form_close();
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->
