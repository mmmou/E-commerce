<div id="mainBody">
    <div class="container">
        <hr class="soften">
        <h1>Edit Subcategory</h1>
        <hr class="soften"/>
        <?php 
        
           
        foreach ($selSCat as $scat) {
            		
            //Form Start   
        $data = array(
            "class" => "form-horizontal",
            "id" => "",
            "enctype" => "multipart/form-data"
        );
        $hid = array("id"=>$scat->id);
        echo form_open(base_url() . "subcategory_management/update", $data, $hid);
       
        //Subcategory Name
        echo '<div class="control-group">';
        //Subcategory Label
        $data = array(
            "class" => "control-label",
            "for" => "title"
            
        );
        echo form_label("Subcategory", "", $data);
        echo '<div class="controls">';
        //Subcategory title input
        $data = array(
            "name" => "scat",
            "placeholder" => "Subcategory",
            "value" => $scat->name,
            "required"=>"required"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //title Close	

         //Category Start
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("Category", "", $data);
        echo '<div class="controls">';
        $data = array();
        foreach ($allCat as $dt) {
            $data[$dt->id] = $dt->name;
        }
        echo form_dropdown("categoryid", $data, $scat->categoryid);

        echo '</div>';
        echo '</div>';
        //Category Close


        //Submit start  <span class="btn btn-large btn-success">Login</span>
        echo '<div class="control-group">';
        $data = array(
            "class" => "control-label"
        );
        echo form_label("", "", $data);
        echo "<div class='controls'>";
        $data = array(
            "class" => "btn btn-large btn-success",
            "name" => "sub",
            "type" => "submit",
            "value" => "Submit"
        );
        echo form_input($data);
        echo '</div>';
        echo '</div>';
        //Submit end
      
        
        //form close


       

        echo form_close();


                }
        
        ?>


    </div>
</div>
<!-- MainBody End ============================= -->

 