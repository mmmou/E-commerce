<div id="sidebar" class="span3">
   <div class="well well-small"><a id="myCart" href="<?php echo base_url(); ?>nhclc/product_summary"><img src="<?php echo base_url(); ?>themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>
   <ul id="sideManu" class="nav nav-tabs nav-stacked">    
      <?php
      foreach ($allCat as $cat) {
         ?>
         <li class="subMenu"><a> <?php echo $cat->name; ?> </a>
            <ul style="display:none">
               <?php
               foreach ($allSCat as $scat) {
                  if($scat->categoryid == $cat->id){
                  ?>
               <li><a href="<?php echo base_url() . Replace($cat->name) . "/" . Replace($scat->name) . "/{$scat->id}"; ?>"><i class="icon-chevron-right"></i><?php echo $scat->name; ?> <small>(<?php echo $scat->tProduct; ?>)</small></a></li>    
                  <?php
                  }
               }
               ?>
            </ul>
         </li>
         <?php
      }
      ?>
   </ul>
   <br/>
   <div class="thumbnail">
      <img src="<?php echo base_url(); ?>themes/images/products/panasonic.jpg" alt="Bootshop panasonoc New camera"/>
      <div class="caption">
         <h5>Panasonic</h5>
         <h4 style="text-align:center"><a class="btn" href="<?php echo base_url(); ?>nhclc/product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
      </div>
   </div><br/>
   <div class="thumbnail">
      <img src="<?php echo base_url(); ?>themes/images/products/kindle.png" title="Bootshop New Kindel" alt="Bootshop Kindel">
      <div class="caption">
         <h5>Kindle</h5>
         <h4 style="text-align:center"><a class="btn" href="<?php echo base_url(); ?>nhclc/product_details.html"> <i class="icon-zoom-in"></i></a> <a class="btn" href="#">Add to <i class="icon-shopping-cart"></i></a> <a class="btn btn-primary" href="#">$222.00</a></h4>
      </div>
   </div><br/>
   <div class="thumbnail">
      <img src="<?php echo base_url(); ?>themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
      <div class="caption">
         <h5>Payment Methods</h5>
      </div>
   </div>
</div>