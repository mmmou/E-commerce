<div id="mainBody">
   <div class="container">
      <hr class="soften">
      <h1>Report</h1>
      <hr class="soften"/>
      <?php
      $msg = $this->session->userdata("msg");
      if ($msg != NULL) {
         echo '<div class="alert alert-success alert-dismissible" role="alert">';
         echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
         echo $msg;
         echo "</div>";
         $this->session->unset_userdata("msg");
      }

      echo validation_errors();

      $data = array(
          "class" => "form-horizontal",
          "id" => "TestId"
      );
      echo form_open(base_url() . "report", $data);

      //Date Start
      echo '<div class="control-group">';
      //Label Start

      $data = array("class" => "control-label");
      echo form_label("Title", "", $data);

      echo '<div class="controls">';
      $data = array(
          "name" => "title",
          "value" => set_value("title")
      );
      echo form_input($data);
      echo "</div>";
      echo "</div>";

      //Date Start
      echo '<div class="control-group">';
      //Label Start

      $data = array("class" => "control-label");
      echo form_label("Start Date", "", $data);

      echo '<div class="controls">';
      $data = array(
          "name" => "sdate",
          "value" => set_value("sdate")
      );
      echo form_input($data);
      echo "</div>";
      echo "</div>";



      //End Date
      echo '<div class="control-group">';
      //Label Start

      $data = array("class" => "control-label");
      echo form_label("End Date", "", $data);

      echo '<div class="controls">';
      $data = array(
          "name" => "edate",
          "value" => set_value("edate")
      );
      echo form_input($data);
      echo "</div>";
      echo "</div>";

      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("Category", "", $data);
      echo '<div class="controls">';
      $data = array();
      $data[] = "All Category";
      foreach ($allCat as $dt) {
         $data[$dt->id] = $dt->name;
      }
      echo form_dropdown("catid", $data, "", array("class" => "btn btn-default dropdown-toggle"));
      echo '</div>';
      echo '</div>';

      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("Sub Category", "", $data);
      echo '<div class="controls">';
      $data = array();
      $data[] = "All Sub Category";
      foreach ($allSCat as $dt) {
         $data[$dt->id] = $dt->name;
      }
      echo form_dropdown("scatid", $data, "", array("class" => "btn btn-default dropdown-toggle"));
      echo '</div>';
      echo '</div>';

//Submit Button
      echo '<div class="control-group">';


      echo '<div class="controls">';
      $data = array(
          "name" => "sub",
          "value" => "submit",
          "class" => "btn btn-large btn-success"
      );
      echo form_submit($data);
      echo "</div>";
      echo "</div>";


      echo form_close();
      ?>




   </div></div>
