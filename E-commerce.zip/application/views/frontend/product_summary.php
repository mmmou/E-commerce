<div id="mainBody">
   <div class="container">
      <div class="row">
         <!-- Sidebar ================================================== -->
         <?php
         $pdtid = $this->session->userdata("pdtid");
         $qtyid = $this->session->userdata("qtyid");
         $pPrice = $this->session->userdata("pdtPrice");

         if (isset($sidebar)) {
            echo $sidebar;
         }
         ?>
         <!-- Sidebar end=============================================== -->
         <div class="span9">
            <ul class="breadcrumb">
               <li><a href="index.html">Home</a> <span class="divider">/</span></li>
               <li class="active"> SHOPPING CART</li>
            </ul>
            <h3>  SHOPPING CART [ <small>3 Item(s) </small>]<a href="products.html" class="btn btn-large pull-right"><i class="icon-arrow-left"></i> Continue Shopping </a></h3>	
            <hr class="soft"/>
            

            <table class="table table-bordered">
               <thead>
                  <tr>
                     <th>Product</th>
                     <th>Title</th>
                     <th>Quantity/Update</th>
                     <th>Price</th>
                     <th>Discount</th>
                     <th>Vat</th>
                     <th>Total</th>
                  </tr>
               </thead>
               <tbody>
                  <tr>
                     <?php
                     $pdtid = $this->session->userdata("pdtid");
                     $qtyid = $this->session->userdata("qtyid");
                     //$this->session->unset_userdata("pdtPrice");
                     $total = 0;
                     foreach ($selPdt as $pdt) {
                        for ($i = 0; $i < count($pdtid); $i++) {
                           if ($pdtid[$i] == $pdt->id) {
                              ?>
                              <td> <img width="60" src="<?php echo base_url() . "product/final/product_{$pdt->id}.{$pdt->picture}"; ?>" alt=""/></td>
                              <td><?php echo $pdt->title; ?></td>
                              <td>
                                 <div class="input-append">
                                    <input class="span1" style="max-width:34px" placeholder="Qty" id="qty-<?php echo $pdtid[$i]; ?>" value="<?php echo $qtyid[$i]; ?>" size="16" type="text">
                                    <button class="btn u-btn" id="p-<?php echo $pdtid[$i]; ?>" type="button">U</button>
                                    <button class="btn btn-danger d-btn"  id="d-<?php echo $pdtid[$i]; ?>" type="button"><i class="icon-remove icon-white"></i></button>
                                 </div>
                              </td>
                              <td><?php echo $pdt->price; ?></td>
                              <td><?php echo $pdt->discount; ?> %</td>
                              <td><?php echo $pdt->vat; ?> %</td>
                              <td><span id="total-<?php echo $pdtid[$i]; ?>">৳ <?php
                                    $r = Cal($pdt->price, $pdt->vat, $pdt->discount) * $qtyid[$i];
                                    echo $r;
                                    $total += $r;
                                    ?>
                                 </span></td>
                           </tr>
                           <?php
                        }
                     }
                  }
                  ?>
                  <tr>
                     <td colspan="6" style="text-align:right"><strong>TOTAL PRICE = </strong></td>
                     <td class="label label-important" style="display:block"> <strong id="totalPrice"> ৳ <?php echo $total; ?> </strong></td>
                  </tr>
               </tbody>
            </table>
            	
            
            <?php
            $type = $this->session->userdata("type");
               if($type == NULL){
            ?>
            <table class="table table-bordered">
               <tr><th> I AM ALREADY REGISTERED  </th></tr>
               <tr> 
                  <td>
                     <form action="<?php echo base_url(); ?>login/check" method="post" class="form-horizontal">
                        <div class="control-group">
                           <label class="control-label" for="inputUsername">Username</label>
                           <div class="controls">
                              <input type="text" id="inputUsername" placeholder="Username">
                           </div>
                        </div>
                        <div class="control-group">
                           <label class="control-label" for="inputPassword1">Password</label>
                           <div class="controls">
                              <input type="password" id="inputPassword1" placeholder="Password">
                           </div>
                        </div>
                        <div class="control-group">
                           <div class="controls">
                              <button type="submit" class="btn">Sign in</button> OR <a href="<?php echo base_url(); ?>register_management" class="btn">Register Now!</a>
                           </div>
                        </div>
                        <div class="control-group">
                           <div class="controls">
                              <a href="forgetpass.html" style="text-decoration:underline">Forgot password ?</a>
                           </div>
                        </div>
                     </form>
                  </td>
               </tr>
            </table>	
            
            <?php
               }
               else{
              ?>
            <form action="<?php echo base_url() ?>purchase" method="post">
               Enter Shipping Address:
               <textarea name="shipping"></textarea>   <br /><br />
               <input type="submit" value="Confirm?" />
            </form>
            <?php
               }
            ?>

         </div>
      </div></div>
</div>

<script>
               $(document).ready(function() {
                  $(".d-btn").click(function() {
                     $(this).parent().parent().parent().fadeOut();
                     var id = $(this).attr("id");
                     id = id.substring(2);
                     var dataString = "id=" + id;
                     $.ajax({
                        type: 'POST',
                        data: dataString,
                        url: "<?php echo base_url(); ?>cart/remove",
                        success: function(data) {
                           alert(data['msg']);
                           $("#totalPrice, #totalPrice").text(data['sTotal']);
                        }
                     });
                  });
                  $(".u-btn").click(function() {
                     var id = $(this).attr("id");
                     id = id.substring(2);
                     var qty = $("#qty-" + id).val();

                     var dataString = "qty=" + qty + "&id=" + id;
                     $.ajax({
                        type: 'POST',
                        data: dataString,
                        url: "<?php echo base_url(); ?>cart/update",
                        success: function(data) {
                           alert(data['msg']);
                           if (data['status'] == 1) {
                              $("#totalPrice, #totalPrice").text(data['price']);
                              $("#total-" + id).text(data['sTotal']);
                           }
                        }
                     });

                  });
               });
            </script>
