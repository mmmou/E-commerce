<div id="mainBody">
   <div class="container">
      <hr class="soften">
      <h1>Register</h1>
      <hr class="soften"/>
      <?php
      $msg = $this->session->userdata("msg");
      if ($msg != NULL) {
         echo '<div class="alert alert-success alert-dismissible" role="alert">';
         echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>';
         echo $msg;
         echo "</div>";
         $this->session->unset_userdata("msg");
      }
      echo validation_errors();

      //Form Start
      $data = array(
          "class" => "form-horizontal",
          "id" => "",
          "enctype" => "multipart/form-data"
      );
      echo form_open(base_url() . "register_management/insert", $data);

      //Product Title
      echo '<div class="control-group">';
      //Product Label
      $data = array(
          "class" => "control-label",
          "for" => "title"
      );
      echo form_label("Name", "", $data);
      echo '<div class="controls">';
      //Product title input
      $data = array(
          "name" => "name",
          "placeholder" => "Name",
          "value" => set_value("title")
      );
      echo form_input($data);
      echo '</div>';
      echo '</div>';
      //title Close
      //email start
      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("Email", "", $data);
      echo '<div class="controls">';
      $data = array(
          "name" => "email",
          "placeholder" => "Email"
      );
      echo form_input($data);
      echo '</div>';
      echo '</div>';
      //email close
      //pass start
      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("Password", "", $data);
      echo '<div class="controls">';
      $data = array(
          "name" => "pass",
          "placeholder" => "Password"
      );
      echo form_password($data);

      echo '</div>';
      echo '</div>';
      //pass close
      //contact start
      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("Contact", "", $data);
      echo '<div class="controls">';
      $data = array(
          "name" => "con",
          "placeholder" => "Contact"
      );
      echo form_input($data);
      echo '</div>';
      echo '</div>';
      //contact close
      //City Start
      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("City", "", $data);
      echo '<div class="controls">';
      $data = array();
      foreach ($allCity as $dt) {
         $data[$dt->id] = $dt->name;
      }
      echo form_dropdown("city", $data, "", array("class" => "btn btn-default dropdown-toggle"));
      echo '</div>';
      echo '</div>';
      //City Close    
      //Submit start  <span class="btn btn-large btn-success">Login</span>
      echo '<div class="control-group">';
      $data = array(
          "class" => "control-label"
      );
      echo form_label("", "", $data);
      echo "<div class='controls'>";
      $data = array(
          "class" => "btn btn-large btn-success",
          "name" => "sub",
          "type" => "submit",
          "value" => "Submit"
      );
      echo form_input($data);
      echo '</div>';
      echo '</div>';
      //Submit end
      //form close
      echo form_close();
      ?>

   </div>
</div>
<!-- MainBody End ============================= -->

<link href="<?php echo base_url() ?>bootstrap/css/bootstrap-multiselect.css"
      rel="stylesheet" type="text/css" />

