<div id="mainBody">
   <div class="container">
      <div class="row">
         <!-- Sidebar ================================================== -->
         <?php
         if (isset($sidebar)) {
            echo $sidebar;
         }
         ?>
         <!-- Sidebar end=============================================== -->
         <div class="span9">
            <?php
            foreach ($selPdt as $pdt) {
               ?>
               <ul class="breadcrumb">
                  <li><a href="<?php echo base_url(); ?>">Home</a> <span class="divider">/</span></li>
                  <?php
                  foreach ($selPd as $p) {
                     foreach ($allSCat as $scat) {
                        foreach ($allCat as $cat) {
                           if (($p->subcategoryid) == ($scat->id)) {
                              if (($scat->categoryid) == ($cat->id)) {
                                 ?>
                                 <li><a href="#"><?php echo $cat->name; ?></a> <span class="divider">/</span></li>
                                 <?php
                              }
                           }
                        }
                     }
                  }
                  ?>
                  <li class="active">product Details</li>
               </ul>	
               <div class="row">	  
                  <div id="gallery" class="span3">
                     <a href="<?php echo base_url(); ?>themes/images/products/large/f1.jpg" title="Fujifilm FinePix S2950 Digital Camera">
                        <img src="<?php echo base_url() . "product/final/product_{$pdt->id}.{$pdt->picture}"; ?>" style="width:100%" alt="Fujifilm FinePix S2950 Digital Camera"/>
                     </a>
                     <div id="differentview" class="moreOptopm carousel slide">

                        <!--  
                              <a class="left carousel-control" href="#myCarousel" data-slide="prev">‹</a>
                        <a class="right carousel-control" href="#myCarousel" data-slide="next">›</a> 
                        -->
                     </div>

                     <div class="btn-toolbar">
                        <div class="btn-group">
                           <span class="btn"><i class="icon-envelope"></i></span>
                           <span class="btn" ><i class="icon-print"></i></span>
                           <span class="btn" ><i class="icon-zoom-in"></i></span>
                           <span class="btn" ><i class="icon-star"></i></span>
                           <span class="btn" ><i class=" icon-thumbs-up"></i></span>
                           <span class="btn" ><i class="icon-thumbs-down"></i></span>
                        </div>
                     </div>
                  </div>
                  <div class="span6">
                     <h3><?php echo $pdt->title; ?> </h3>				
                     <hr class="soft"/>
                     <form action="<?php echo base_url() ?>" method="post" class="form-horizontal qtyFrm">
                        <div class="control-group">
                           <label class="control-label">Pridce <span>৳ <?php echo Cal($pdt->price, $pdt->vat, $pdt->discount); ?></span></label>
                           <div class="controls">
                              <input type="hidden" name="id" id="id" value="<?php echo $pdt->id ?>" />
                              <input type="text" name="qty" id="qty" class="span1" placeholder="Qty."/>
                              <button type="submit" class="btn btn-large btn-primary pull-right" id="cart"> Add to cart <i class="icon-shopping-cart"></i></button>
                           </div>
                        </div>
                     </form>

                     <hr class="soft"/>
                     <form class="form-horizontal qtyFrm pull-right">
                        <div class="control-group">
                           <label class="control-label"><span>Color</span></label>
                           <div class="controls">
                              <select class="span2">
                                 <?php
                                 $data = array();
                                 $count = 0;
                                 foreach ($selPdt as $p) {
                                    if ($data) {
                                       foreach ($data as $d) {
                                          if ($p->colorname == $d) {
                                             $count++;
                                             break;
                                          }
                                       }
                                    }
                                    if ($count == 0) {
                                       echo "<option>{$p->colorname}</option>";
                                       $data[] = $p->colorname;
                                    }
                                    $count = 0;
                                 }
                                 ?>

                              </select>
                           </div>
                        </div>
                        <div class="control-group">
                           <label class="control-label"><span>Size</span></label>
                           <div class="controls">
                              <select class="span2">
                                 <?php
                                 $data = array();
                                 $count = 0;
                                 foreach ($selPdt as $p) {
                                    if ($data) {
                                       foreach ($data as $d) {
                                          if ($p->sizename == $d) {
                                             $count++;
                                             break;
                                          }
                                       }
                                    }
                                    if ($count == 0) {
                                       echo "<option>{$p->sizename}</option>";
                                       $data[] = $p->sizename;
                                    }
                                    $count = 0;
                                 }
                                 ?>

                              </select>
                           </div>
                        </div>
                        <div class="control-group">
                           <label class="control-label"><span>Tags</span></label>
                           <div class="controls">
                              <div class="span2">
                                 <?php
                                 $data = array();
                                 $count = 0;
                                 foreach ($selPdt as $p) {
                                    if ($data) {
                                       foreach ($data as $d) {
                                          if ($p->tagsname == $d) {
                                             $count++;
                                          }
                                       }
                                    }
                                    if ($count == 0) {
                                       echo "<a class=\"btn btn-primary\" href=\"#\">{$p->tagsname}</a><br/>";
                                       $data[] = $p->tagsname;
                                    }
                                    $count = 0;
                                 }
                                 ?>

                              </div>
                           </div>
                        </div>
                     </form>
                     <hr class="soft clr"/>
                     <p>
                        <?php
                        echo read_file("files/product_{$pdt->id}.txt");
                        ?>
                     </p>

                     <br class="clr"/>
                     <a href="#" name="detail"></a>
                     <hr class="soft"/>
                  </div>

                  <div class="span9">

                     <?php
                     $type = $this->session->userdata("type");
                     if ($type != NULL) {
                        ?>
                     <form action="<?php echo base_url() ?>product/insert_comment" method="post">
                           <select name="ratings">
                              <option value="0">Choose Ratings</option>
                              <option value="1">Bad</option>
                              <option value="2">Not Bad</option>
                              <option value="3">Average</option>
                              <option value="4">Good</option>
                              <option value="5">Excellent</option>

                           </select>

                           <textarea name="comment"></textarea>
                           <br>
                           <div class="width-100">
                              <label>This question is for testing whatever you are a human visitor and to prevent automated spam submissions.</label>             
                              <div class="cap-img">
                                 <img src="<?php echo base_url() . "captcha/{$captcha['cap_name']}"; ?>" id='cap_img' />
                              </div>
                              <span id='reload'><img src="<?php echo base_url() ?>product/reload.png" title="Reload Captcha" alt="reload" /></span>
                              <br class="clear" />
                              <div class="width-50">
                                 <?php
                                 $data = array(
                                     "name" => "cap",
                                     "required" => "required",
                                     "placeholder" => "Enter Captcha",
                                     "value" => ""
                                 );
                                 echo form_input($data);
                                 ?>
                              </div>
                           </div>

                           <input type="submit" class="btn btn-primary" />.



                        </form>

                        <?php
                     } else {
                        ?>
                        <h4>Please Login For Comment</h4>  <a href="#login" role="button" data-toggle="modal" class="btn btn-primary">  Click Here</a>
                        <?php
                     }
                     ?>


                     <?php
                     if ($allCom) {
                        $display = "";
                        $num = 0;
                        $rating = 0;
                        foreach ($allCom as $com) {
                           $display .= "<p><b>{$com->name}</b>: {$com->rating}</p>";
                           $num++;
                           $rating += $com->rating;
                        }
                        echo "Average Rating: " . ($rating / $num);
                        echo $display;
                     } else {
                        echo "No Comment Avaliable";
                     }
                     ?>
                  </div>

               </div>
               <?php
               break;
            }
            ?>
         </div>
      </div> </div>
</div>



<script>
   $(document).ready(function() {
      $("#cart").click(function() {
         var qty = $("#qty").val();
         var id = $("#id").val();
         if (isNaN(qty)) {
            alert("Invalid Format");
         }
         else if (parseInt(qty) != qty) {
            alert("Quantity must be an Integer");
         }
         else {
            var dataString = "qty=" + qty + "&id=" + id;
            $.ajax({
               type: 'POST',
               data: dataString,
               url: "<?php echo base_url(); ?>cart/add_to_cart",
               success: function(data) {
                  alert(data['msg']);
                  if (data['status'] == 1) {
                     $("#totalPrice").text(data['price']);
                     var tqty = parseInt($("#totalItem").text());
                     $("#totalItem").text(++tqty);
                  }
               }
            });
         }
         return false;
      });

      $("#reload").click(function() {
         $.ajax({
            type: 'POST',
            data: "",
            url: "<?php echo base_url() ?>product/captcha_generator",
            success: function(data) {
               $("#cap_img").attr("src", "<?php echo base_url() . "captcha/"; ?>" + data["cap_name"]);
            }
         });
      });
   });
</script>














