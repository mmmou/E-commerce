<div id="carouselBlk">
   <div id="myCarousel" class="carousel slide">
      <div class="carousel-inner">
         <div class="item active">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img style="width:100%" src="<?php echo base_url(); ?>themes/images/carousel/1.png" alt="special offers"/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img style="width:100%" src="<?php echo base_url(); ?>themes/images/carousel/2.png" alt=""/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img src="<?php echo base_url(); ?>themes/images/carousel/3.png" alt=""/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>

            </div>
         </div>
         <div class="item">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img src="<?php echo base_url(); ?>themes/images/carousel/4.png" alt=""/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>

            </div>
         </div>
         <div class="item">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img src="<?php echo base_url(); ?>themes/images/carousel/5.png" alt=""/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>
            </div>
         </div>
         <div class="item">
            <div class="container">
               <a href="<?php echo base_url(); ?>nhclc/register"><img src="<?php echo base_url(); ?>themes/images/carousel/6.png" alt=""/></a>
               <div class="carousel-caption">
                  <h4>Second Thumbnail label</h4>
                  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
               </div>
            </div>
         </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
   </div> 
</div>
<div id="mainBody">
   <div class="container">
      <div class="row">
         <!-- Sidebar ================================================== -->
         <?php
         if (isset($sidebar)) {
            echo $sidebar;
         }
         ?>

         <!-- Sidebar end=============================================== -->
         <div class="span9">		
            <div class="well well-small">
               <h4>Featured Products <small class="pull-right">200+ featured products</small></h4>
               <div class="row-fluid">
                  <div id="featured" class="carousel slide">
                     <div class="carousel-inner">
                        <div class="item active">
                           <ul class="thumbnails">
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/b1.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/b2.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/b3.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/b4.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                        <div class="item">
                           <ul class="thumbnails">
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/5.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <i class="tag"></i>
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/6.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/7.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/8.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                        <div class="item">
                           <ul class="thumbnails">
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/9.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/10.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/11.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/1.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                        <div class="item">
                           <ul class="thumbnails">
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/2.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/3.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/4.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                              <li class="span3">
                                 <div class="thumbnail">
                                    <a href="product_details.html"><img src="<?php echo base_url(); ?>themes/images/products/5.jpg" alt=""></a>
                                    <div class="caption">
                                       <h5>Product name</h5>
                                       <h4><a class="btn" href="product_details.html">VIEW</a> <span class="pull-right">$222.00</span></h4>
                                    </div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                     </div>
                     <a class="left carousel-control" href="#featured" data-slide="prev">‹</a>
                     <a class="right carousel-control" href="#featured" data-slide="next">›</a>
                  </div>
               </div>
            </div>
            <h4>Latest Products </h4>
            <ul class="thumbnails">
               <?php
               $i = 0;
               foreach ($allPdt as $pdt) {
                  if ($i % 3 == 0) {
                     echo '<ul class="thumbnails">';
                  }
                  ?>
                  <li class="span3">
                     <div class="thumbnail">
                        <a  href="<?php echo base_url() . Replace($pdt->cname) . "/" . Replace($pdt->scname) . "/{$pdt->id}/" . Replace($pdt->title); ?>"><img src="<?php echo base_url() . "product/final/product_{$pdt->id}.{$pdt->picture}"; ?>" alt=""/></a>
                        <div class="caption">
                           <h5><?php echo $pdt->title; ?></h5>
                           <h4 style="text-align:center; padding: 0 20px;"><a class="btn btn-primary" href="#">৳ <?php echo Cal($pdt->price, $pdt->vat, $pdt->discount); ?></a> <a class="btn btn-warning" href="#"><del>৳ <?php echo Cal($pdt->price, $pdt->vat, 0); ?></del></a></h4>
                        </div>
                     </div>
                  </li>
                  <?php
                  if($i%3==2){
                     echo "</ul>";
                  }
                  $i++;
               }
               if(count($allPdt) %3 != 0){
                  echo "</ul>";
               }
               ?>
                  <div style="text-align: center">
                     <?php 
                     if($cpage>1){
                  $temp = $cpage-1;
                  echo "<a href='".  base_url() . "?page={$temp}" ."' class='page'>PREV</a>";
               }
               $page = 1;
               for($i=1; $i<=$totalPdt; $i = $i + $per_page){
                  if($page == $cpage){
                  echo "<a href='".  base_url() . "?page={$page}" ."' class='page-active'>{$page}</a>";
                  }
                  else{
                     echo "<a href='".  base_url() . "?page={$page}" ."' class='page'>{$page}</a>";
                  }
                  $page++;
               }
               if($cpage *$per_page < $totalPdt){
                  $temp = $cpage+1;
                  echo "<a href='".  base_url() . "?page={$temp}" ."' class='page'>NEXT</a>";
               }
                     ?>
                  </div>
               <?php 
               
               
               ?>
         </div>
      </div>
   </div>
</div>
<style>
   .page{
      padding: 7px;
      background-color: #00ccff;
      margin: 5px;
      border-radius: 10px;
      text-align: center;
      margin: 0 20px;
   }
   .page-active{
      padding: 7px;
      background-color: #1fa80a;
      margin: 5px;
      color:white;
      border-radius: 10px;
      text-decoration: none;
      text-align: center;
   }
   .page:hover{
      text-decoration: none;
      background-color: #1fa80a;
      color: white;
   }
   
</style>